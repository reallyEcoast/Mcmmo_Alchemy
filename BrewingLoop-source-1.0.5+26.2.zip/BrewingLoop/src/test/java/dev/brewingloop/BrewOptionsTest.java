package dev.brewingloop;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * The user's request was that every behaviour the script hard-coded is
 * selectable, so these tests pin the option defaults and the clamping rules.
 */
class BrewOptionsTest {

    @Test void defaultsMatchTheOriginalScript() {
        BrewOptions options = new BrewOptions();
        // Script: Drop = true, Throw = false, Water = true, Loop = true,
        // showBoxes = true, delay = 5, distance = 4.0, loopDelay = 5.
        assertEquals(BrewOptions.Output.DROP, options.output());
        assertEquals(BrewOptions.WaterSource.AUTO_FILL, options.waterSource());
        assertTrue(options.loop());
        assertTrue(options.highlightStands());
        assertEquals(5, options.actionDelay());
        assertEquals(4.0, options.searchRadius(), 0.0001);
        assertEquals(5, options.loopDelay());
    }

    @Test void everyScriptConstantHasAChoice() {
        BrewOptions options = new BrewOptions();
        options.setOutput(BrewOptions.Output.KEEP);
        options.setWaterSource(BrewOptions.WaterSource.USE_EXISTING);
        options.setLoop(false);
        options.setHighlightStands(false);
        options.setActionDelay(8);
        options.setSearchRadius(6.0);
        options.setLoopDelay(0);

        assertEquals(BrewOptions.Output.KEEP, options.output());
        assertEquals(BrewOptions.WaterSource.USE_EXISTING, options.waterSource());
        assertFalse(options.loop());
        assertFalse(options.highlightStands());
        assertEquals(8, options.actionDelay());
        assertEquals(6.0, options.searchRadius(), 0.0001);
        assertEquals(0, options.loopDelay());
    }

    @Test void delayAndRadiusAreClamped() {
        BrewOptions options = new BrewOptions();
        options.setActionDelay(0);
        assertEquals(1, options.actionDelay(), "a zero delay would spam the server");
        options.setActionDelay(-4);
        assertEquals(1, options.actionDelay());

        options.setSearchRadius(0.1);
        assertEquals(1.0, options.searchRadius(), 0.0001);
        options.setSearchRadius(99.0);
        assertEquals(8.0, options.searchRadius(), 0.0001, "must stay inside plausible reach");

        options.setLoopDelay(-3);
        assertEquals(0, options.loopDelay());
    }

    @Test void menuChoicesAreWithinTheClampedRange() {
        BrewOptions options = new BrewOptions();
        for (int choice : BrewOptions.DELAY_CHOICES) {
            options.setActionDelay(choice);
            assertEquals(choice, options.actionDelay());
        }
        for (double choice : BrewOptions.RADIUS_CHOICES) {
            options.setSearchRadius(choice);
            assertEquals(choice, options.searchRadius(), 0.0001);
        }
    }

    @Test void throwDegradesToKeepForDrinkablePotions() {
        BrewOptions options = new BrewOptions();
        options.setOutput(BrewOptions.Output.THROW);
        assertEquals(BrewOptions.Output.KEEP, options.resolvedOutput("drink"));
        assertEquals(BrewOptions.Output.THROW, options.resolvedOutput("splash"));
        assertEquals(BrewOptions.Output.THROW, options.resolvedOutput("lingering"));
    }

    @Test void otherOutputsAreNeverRewritten() {
        BrewOptions options = new BrewOptions();
        options.setOutput(BrewOptions.Output.DROP);
        assertEquals(BrewOptions.Output.DROP, options.resolvedOutput("drink"));
        options.setOutput(BrewOptions.Output.KEEP);
        assertEquals(BrewOptions.Output.KEEP, options.resolvedOutput("splash"));
    }

    @Test void copyIsIndependentOfTheLiveOptions() {
        BrewOptions live = new BrewOptions();
        live.setActionDelay(12);
        BrewOptions snapshot = live.copy();
        live.setActionDelay(2);
        live.setOutput(BrewOptions.Output.KEEP);

        assertEquals(12, snapshot.actionDelay(), "a running job must not change mid-flight");
        assertEquals(BrewOptions.Output.DROP, snapshot.output());
    }
}
