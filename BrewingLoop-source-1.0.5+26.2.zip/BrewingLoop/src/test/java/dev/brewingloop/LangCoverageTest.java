package dev.brewingloop;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Scrapes every {@code brewingloop.*} / {@code key.brewingloop.*} key out of the
 * sources and checks every language file defines it. A missing key renders in-game
 * as raw text like {@code brewingloop.pause.noFuel}, which is exactly the kind of
 * silent breakage that is invisible until a player hits it.
 */
class LangCoverageTest {
    private static final Pattern KEY = Pattern.compile("\"((?:key\\.)?brewingloop\\.[a-zA-Z0-9_.]+)\"");

    /** Every locale shipped in the jar. en_us is the reference the others match. */
    private static final String REFERENCE = "en_us";
    private static final List<String> TRANSLATIONS = List.of("zh_tw", "zh_hk", "zh_cn");
    private static final List<String> ALL_LOCALES =
            Stream.concat(Stream.of(REFERENCE), TRANSLATIONS.stream()).toList();

    /** Matches either an escaped percent or a {@code %s} with an optional explicit index. */
    private static final Pattern FORMAT_ARG = Pattern.compile("%%|%(?:(\\d+)\\$)?s");

    private static JsonObject lang(String locale) throws Exception {
        String resource = "/assets/brewingloop/lang/" + locale + ".json";
        try (var input = LangCoverageTest.class.getResourceAsStream(resource)) {
            assertNotNull(input, resource + " must be packaged");
            return JsonParser.parseReader(new InputStreamReader(input, StandardCharsets.UTF_8)).getAsJsonObject();
        }
    }

    private static Set<String> keysUsedInSources() throws Exception {
        Path sources = Path.of("src", "mod", "java");
        assertTrue(Files.isDirectory(sources), "source directory must exist");
        Set<String> keys = new TreeSet<>();
        try (var files = Files.walk(sources)) {
            for (Path file : files.filter(p -> p.toString().endsWith(".java")).toList()) {
                Matcher matcher = KEY.matcher(Files.readString(file, StandardCharsets.UTF_8));
                while (matcher.find()) {
                    keys.add(matcher.group(1));
                }
            }
        }
        assertFalse(keys.isEmpty(), "key scraping found nothing, the test itself is broken");
        return keys;
    }

    /**
     * Returns which argument positions a format string actually consumes, with
     * implicit {@code %s} numbered left to right. Translations are free to reorder
     * with {@code %2$s}-style indices, but they must consume the same positions the
     * code supplies: referencing an index the caller never passes throws
     * {@link java.util.MissingFormatArgumentException} the moment the line is shown.
     */
    private static Set<Integer> argumentPositions(String format) {
        Set<Integer> positions = new TreeSet<>();
        Matcher matcher = FORMAT_ARG.matcher(format);
        int implicit = 0;
        while (matcher.find()) {
            if (matcher.group().equals("%%")) {
                continue;
            }
            positions.add(matcher.group(1) != null ? Integer.parseInt(matcher.group(1)) : ++implicit);
        }
        return positions;
    }

    @Test void everyLocaleDefinesEveryKeyUsedInCode() throws Exception {
        Set<String> used = keysUsedInSources();
        for (String locale : ALL_LOCALES) {
            JsonObject lang = lang(locale);
            List<String> missing = new ArrayList<>();
            for (String key : used) {
                // Catalog keys built from Items use vanilla's own keys, not ours.
                if (!lang.has(key)) {
                    missing.add(key);
                }
            }
            assertTrue(missing.isEmpty(), locale + " is missing: " + missing);
        }
    }

    @Test void catalogKeysAreTranslated() throws Exception {
        List<String> ours = new ArrayList<>();
        BrewCatalog.RECIPES.forEach(recipe -> ours.add(recipe.nameKey()));
        BrewCatalog.VARIANTS.forEach(variant -> ours.add(variant.nameKey()));
        BrewCatalog.FORMS.forEach(form -> ours.add(form.nameKey()));
        for (BrewOptions.Output output : BrewOptions.Output.values()) {
            ours.add(output.nameKey());
        }
        for (BrewOptions.WaterSource source : BrewOptions.WaterSource.values()) {
            ours.add(source.nameKey());
        }

        for (String locale : ALL_LOCALES) {
            JsonObject lang = lang(locale);
            List<String> missing = ours.stream().filter(key -> !lang.has(key)).toList();
            assertTrue(missing.isEmpty(), locale + " is missing: " + missing);
        }
    }

    @Test void localesHaveIdenticalKeySets() throws Exception {
        Set<String> reference = new TreeSet<>(lang(REFERENCE).keySet());
        for (String locale : TRANSLATIONS) {
            Set<String> translated = new TreeSet<>(lang(locale).keySet());
            assertEquals(reference, translated, locale + " drifted apart from " + REFERENCE);
        }
    }

    @Test void argumentPositionsMatchBetweenLocales() throws Exception {
        JsonObject reference = lang(REFERENCE);
        for (String locale : TRANSLATIONS) {
            JsonObject translated = lang(locale);
            for (String key : reference.keySet()) {
                Set<Integer> expected = argumentPositions(reference.get(key).getAsString());
                Set<Integer> actual = argumentPositions(translated.get(key).getAsString());
                assertEquals(expected, actual, "argument mismatch for " + key + " in " + locale);
            }
        }
    }

    @Test void argumentPositionHelperUnderstandsReordering() {
        assertEquals(Set.of(1, 2, 3), argumentPositions("Ingredient %s/%s: %s"));
        assertEquals(Set.of(1, 2, 3), argumentPositions("%3$s | %1$s/%2$s"));
        assertEquals(Set.of(), argumentPositions("100%% done"));
        assertEquals(Set.of(1), argumentPositions("50%% of %s"));
    }
}
