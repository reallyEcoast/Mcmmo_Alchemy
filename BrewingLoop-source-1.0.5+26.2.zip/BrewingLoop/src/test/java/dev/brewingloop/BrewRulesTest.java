package dev.brewingloop;

import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BrewRulesTest {

    @Test void planKeepsBaseOrderThenModifierThenForm() {
        List<String> plan = BrewRules.ingredientPlan(
                List.of("nether_wart", "sugar"), "redstone", List.of("gunpowder", "dragon_breath"));
        assertEquals(List.of("nether_wart", "sugar", "redstone", "gunpowder", "dragon_breath"), plan);
    }

    @Test void planOmitsBlankModifier() {
        assertEquals(List.of("nether_wart", "sugar"),
                BrewRules.ingredientPlan(List.of("nether_wart", "sugar"), null, List.of()));
        assertEquals(List.of("nether_wart", "sugar"),
                BrewRules.ingredientPlan(List.of("nether_wart", "sugar"), "  ", List.of()));
    }

    @Test void stockMultipliesEveryStageByStandCount() {
        Map<String, Integer> stock = BrewRules.totalStock(
                List.of("nether_wart", "sugar", "redstone"), 3);
        assertEquals(Map.of("nether_wart", 3, "sugar", 3, "redstone", 3), stock);
    }

    @Test void stockAccumulatesRepeatedIngredient() {
        // Lingering uses gunpowder once and dragon's breath once, but a recipe that
        // repeats an item must ask for it twice per stand.
        Map<String, Integer> stock = BrewRules.totalStock(List.of("gunpowder", "gunpowder"), 2);
        assertEquals(4, stock.get("gunpowder"));
    }

    @Test void stockIsEmptyWithoutStands() {
        assertTrue(BrewRules.totalStock(List.of("nether_wart"), 0).isEmpty());
        assertTrue(BrewRules.totalStock(List.of("nether_wart"), -1).isEmpty());
    }

    @Test void menuSlotMappingPutsHotbarAfterTheMainRows() {
        // A brewing stand menu lists its own 5 slots, then the 27 main rows
        // (menu 5-31), then the hotbar (menu 32-40). The player's inventory uses
        // the opposite order, so a naive "same index" assumption lands three rows
        // away and clicks the wrong item.
        assertEquals(32, BrewRules.menuSlotForInventorySlot(0));
        assertEquals(40, BrewRules.menuSlotForInventorySlot(8));
        assertEquals(5, BrewRules.menuSlotForInventorySlot(9));
        assertEquals(31, BrewRules.menuSlotForInventorySlot(35));
    }

    @Test void menuSlotMappingIsABijectionOverTheStorageSlots() {
        boolean[] seen = new boolean[41];
        for (int slot = 0; slot < BrewRules.STORAGE_SIZE; slot++) {
            int menuSlot = BrewRules.menuSlotForInventorySlot(slot);
            assertTrue(menuSlot >= BrewRules.MENU_MAIN_START && menuSlot <= 40,
                    "inventory slot " + slot + " mapped outside the menu: " + menuSlot);
            assertFalse(seen[menuSlot], "menu slot " + menuSlot + " claimed twice");
            seen[menuSlot] = true;
        }
    }

    @Test void menuSlotMappingRejectsSlotsTheMenuCannotReach() {
        // The off-hand (inventory slot 40) and the armour slots have no
        // counterpart in a brewing stand menu; clicking them is not possible.
        assertEquals(-1, BrewRules.menuSlotForInventorySlot(BrewRules.STORAGE_SIZE));
        assertEquals(-1, BrewRules.menuSlotForInventorySlot(40));
        assertEquals(-1, BrewRules.menuSlotForInventorySlot(-1));
    }

    @Test void inventoryMenuMappingSkipsTheCraftingAndArmourSlots() {
        // InventoryMenu: 0 result, 1-4 crafting, 5-8 armour, 9-35 storage,
        // 36-44 hotbar, 45 off-hand. A raw inventory index would land in the
        // crafting grid or on a piece of armour instead of the intended item.
        assertEquals(36, BrewRules.inventoryMenuSlotFor(0));
        assertEquals(44, BrewRules.inventoryMenuSlotFor(8));
        assertEquals(9, BrewRules.inventoryMenuSlotFor(9));
        assertEquals(35, BrewRules.inventoryMenuSlotFor(35));
        assertEquals(45, BrewRules.inventoryMenuSlotFor(BrewRules.INVENTORY_OFFHAND));
    }

    @Test void inventoryMenuMappingIsABijectionAndNeverHitsReservedSlots() {
        boolean[] seen = new boolean[46];
        for (int slot = 0; slot < BrewRules.STORAGE_SIZE; slot++) {
            int menuSlot = BrewRules.inventoryMenuSlotFor(slot);
            assertTrue(menuSlot >= BrewRules.INVENTORY_MENU_STORAGE_START && menuSlot < 45,
                    "storage slot " + slot + " mapped outside 9-44: " + menuSlot);
            assertFalse(seen[menuSlot], "menu slot " + menuSlot + " claimed twice");
            seen[menuSlot] = true;
        }
    }

    @Test void inventoryMenuMappingRejectsUnreachableIndices() {
        assertEquals(-1, BrewRules.inventoryMenuSlotFor(BrewRules.STORAGE_SIZE));
        assertEquals(-1, BrewRules.inventoryMenuSlotFor(39));
        assertEquals(-1, BrewRules.inventoryMenuSlotFor(-1));
    }

    @Test void theTwoMenuMappingsNeverAgree() {
        // A guard against the mistake that caused 1.0.4 and 1.0.5: using one
        // mapping where the other is needed. If any index mapped to the same
        // number in both schemes, such a mix-up could pass unnoticed there.
        for (int slot = 0; slot < BrewRules.STORAGE_SIZE; slot++) {
            assertNotEquals(BrewRules.menuSlotForInventorySlot(slot),
                    BrewRules.inventoryMenuSlotFor(slot),
                    "inventory slot " + slot + " maps identically in both menus");
        }
    }

    @Test void missingBottlesNeverNegative() {
        assertEquals(3, BrewRules.missingBottles(0));
        assertEquals(1, BrewRules.missingBottles(2));
        assertEquals(0, BrewRules.missingBottles(3));
        assertEquals(0, BrewRules.missingBottles(5));
        assertEquals(3, BrewRules.missingBottles(-2));
    }

    @Test void fuelNeededOnlyWhenExhausted() {
        assertTrue(BrewRules.needsFuel(0));
        assertFalse(BrewRules.needsFuel(1));
        assertFalse(BrewRules.needsFuel(20));
    }

    @Test void fillingRequiresBothBottlesAndSpace() {
        assertTrue(BrewRules.canFillBottles(3, 3, 3));
        assertFalse(BrewRules.canFillBottles(2, 9, 3));
        assertFalse(BrewRules.canFillBottles(9, 2, 3));
        assertTrue(BrewRules.canFillBottles(0, 0, 0));
    }

    @Test void remainingSecondsRoundsUp() {
        assertEquals(0, BrewRules.remainingSeconds(0));
        assertEquals(0, BrewRules.remainingSeconds(-5));
        assertEquals(1, BrewRules.remainingSeconds(1));
        assertEquals(1, BrewRules.remainingSeconds(20));
        assertEquals(2, BrewRules.remainingSeconds(21));
        assertEquals(20, BrewRules.remainingSeconds(400));
    }

    @Test void outputItemFollowsForm() {
        assertEquals("minecraft:potion", BrewRules.outputItem("drink"));
        assertEquals("minecraft:splash_potion", BrewRules.outputItem("splash"));
        assertEquals("minecraft:lingering_potion", BrewRules.outputItem("lingering"));
    }

    @Test void onlySplashAndLingeringCanBeThrown() {
        assertFalse(BrewRules.canThrow("drink"));
        assertTrue(BrewRules.canThrow("splash"));
        assertTrue(BrewRules.canThrow("lingering"));
        assertFalse(BrewRules.canThrow(null));
    }
}
