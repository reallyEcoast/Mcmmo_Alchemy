package dev.brewingloop;

import java.util.EnumSet;
import java.util.Set;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pins which steps have to re-open a brewing stand when the player resumes.
 *
 * <p>Resuming used to jump back to {@code FIND}, which bumped the round counter
 * and reset the stand/ingredient cursors — a pause silently restarted the round
 * and re-fed ingredients into stands that were already brewing. The fix resumes
 * at the interrupted step instead, so this classification is load-bearing: a
 * GUI-driven step wrongly marked resumable would continue with the stand screen
 * closed and immediately pause again on {@code menuClosed}.
 */
class BrewStateTest {
    @Test void guiDrivenStatesReopenTheStand() {
        Set<BrewEngine.State> expected = EnumSet.of(
                BrewEngine.State.PREPARE,
                BrewEngine.State.LOAD_INGREDIENT,
                BrewEngine.State.WAIT_BREW,
                BrewEngine.State.COLLECT);

        for (BrewEngine.State state : BrewEngine.State.values()) {
            assertEquals(expected.contains(state), state.needsOpenStand(),
                    state + " is classified wrongly for resuming");
        }
    }

    @Test void throwingResumesWithoutAStand() {
        // Throwing reads only the player's own inventory, and the stand screen is
        // deliberately closed before it runs; needing a stand would deadlock it.
        assertFalse(BrewEngine.State.THROW_OUTPUT.needsOpenStand());
        assertFalse(BrewEngine.State.FILL_BOTTLES.needsOpenStand());
    }

    @Test void pausedAndIdleAreNeverResumeTargets() {
        // resumeState records the interrupted step, so these two must never
        // qualify as work to return to.
        assertFalse(BrewEngine.State.PAUSED.needsOpenStand());
        assertFalse(BrewEngine.State.IDLE.needsOpenStand());
    }
}
