package dev.brewingloop;

import java.util.List;
import net.minecraft.SharedConstants;
import net.minecraft.server.Bootstrap;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionBrewing;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Replays every catalog entry through vanilla's real brewing table. A recipe or
 * strength variant that the game would reject fails here instead of silently
 * wasting the player's materials in-game.
 */
class BrewCatalogTest {
    private static PotionBrewing brewing;

    @BeforeAll static void bootstrap() {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
        net.minecraft.core.registries.BuiltInRegistries.DATA_COMPONENT_INITIALIZERS
            .build(net.minecraft.data.registries.VanillaRegistries.createLookup())
            .forEach(net.minecraft.core.component.DataComponentInitializers.PendingComponents::apply);
        brewing = PotionBrewing.bootstrap(FeatureFlags.VANILLA_SET);
    }

    /** Runs a plan from a water bottle and returns the resulting stack. */
    private static ItemStack brew(List<BrewCatalog.Ingredient> plan) {
        ItemStack stack = PotionContents.createItemStack(Items.POTION, Potions.WATER);
        for (BrewCatalog.Ingredient ingredient : plan) {
            ItemStack reagent = new ItemStack(ingredient.item());
            assertTrue(brewing.hasMix(stack, reagent),
                    "vanilla rejects " + ingredient.translationKey() + " at this stage");
            stack = brewing.mix(reagent, stack);
        }
        return stack;
    }

    @Test void everyRecipeAndVariantBrewsInVanilla() {
        for (BrewCatalog.Recipe recipe : BrewCatalog.RECIPES) {
            for (BrewCatalog.Variant variant : BrewCatalog.variantsFor(recipe)) {
                List<BrewCatalog.Ingredient> plan =
                        BrewCatalog.plan(recipe, variant, BrewCatalog.FORMS.getFirst());
                ItemStack result = brew(plan);
                assertTrue(result.is(Items.POTION), recipe.id() + " / " + variant.id());
                PotionContents contents = result.get(net.minecraft.core.component.DataComponents.POTION_CONTENTS);
                assertNotNull(contents, recipe.id() + " / " + variant.id() + " produced no potion");
                assertFalse(contents.is(Potions.WATER),
                        recipe.id() + " / " + variant.id() + " never left water");
                assertFalse(contents.is(Potions.AWKWARD),
                        recipe.id() + " / " + variant.id() + " stopped at awkward");
            }
        }
    }

    @Test void splashAndLingeringProduceTheRightItem() {
        BrewCatalog.Recipe swiftness = BrewCatalog.RECIPES.getFirst();
        BrewCatalog.Variant normal = BrewCatalog.variant("normal");

        assertTrue(brew(BrewCatalog.plan(swiftness, normal, form("drink"))).is(Items.POTION));
        assertTrue(brew(BrewCatalog.plan(swiftness, normal, form("splash"))).is(Items.SPLASH_POTION));
        assertTrue(brew(BrewCatalog.plan(swiftness, normal, form("lingering"))).is(Items.LINGERING_POTION));

        // Keep BrewRules.outputItem, which the engine reads, in step with reality.
        assertEquals("minecraft:potion", BrewRules.outputItem("drink"));
        assertEquals("minecraft:splash_potion", BrewRules.outputItem("splash"));
        assertEquals("minecraft:lingering_potion", BrewRules.outputItem("lingering"));
    }

    @Test void variantListsRejectUnsupportedStrengths() {
        // Healing has no extended variant; night vision has no upgraded variant.
        BrewCatalog.Recipe healing = recipe("healing");
        assertTrue(BrewCatalog.variantsFor(healing).stream().noneMatch(v -> v.id().equals("long")));
        BrewCatalog.Recipe nightVision = recipe("night_vision");
        assertTrue(BrewCatalog.variantsFor(nightVision).stream().noneMatch(v -> v.id().equals("strong")));
        // The 1.21-era effects only exist in their base strength.
        for (String id : List.of("wind_charged", "weaving", "oozing", "infested")) {
            assertEquals(1, BrewCatalog.variantsFor(recipe(id)).size(), id);
        }
    }

    @Test void excludedVariantsReallyAreInvalidInVanilla() {
        // Proves the exclusions above are facts about the game, not guesses.
        ItemStack healing = brew(BrewCatalog.plan(recipe("healing"), BrewCatalog.variant("normal"),
                BrewCatalog.FORMS.getFirst()));
        assertFalse(brewing.hasMix(healing, new ItemStack(Items.REDSTONE)),
                "healing unexpectedly accepts redstone");

        ItemStack nightVision = brew(BrewCatalog.plan(recipe("night_vision"), BrewCatalog.variant("normal"),
                BrewCatalog.FORMS.getFirst()));
        assertFalse(brewing.hasMix(nightVision, new ItemStack(Items.GLOWSTONE_DUST)),
                "night vision unexpectedly accepts glowstone dust");
    }

    @Test void planOrdersBaseThenVariantThenForm() {
        List<BrewCatalog.Ingredient> plan = BrewCatalog.plan(recipe("swiftness"),
                BrewCatalog.variant("long"), BrewCatalog.FORMS.getLast());
        assertEquals(List.of(BrewCatalog.NETHER_WART, BrewCatalog.SUGAR, BrewCatalog.REDSTONE,
                BrewCatalog.GUNPOWDER, BrewCatalog.DRAGON_BREATH), plan);
    }

    @Test void ingredientLocalisationKeysResolveToTheRightItem() {
        // A mismatched key would show the wrong name in a pause message.
        for (BrewCatalog.Recipe recipe : BrewCatalog.RECIPES) {
            for (BrewCatalog.Ingredient ingredient : recipe.ingredients()) {
                assertEquals(ingredient.item().getDescriptionId(), ingredient.translationKey(),
                        "wrong key for " + ingredient.translationKey());
            }
        }
        for (BrewCatalog.Variant variant : BrewCatalog.VARIANTS) {
            if (variant.ingredient() != null) {
                assertEquals(variant.ingredient().item().getDescriptionId(),
                        variant.ingredient().translationKey());
            }
        }
        for (BrewCatalog.Form form : BrewCatalog.FORMS) {
            for (BrewCatalog.Ingredient ingredient : form.ingredients()) {
                assertEquals(ingredient.item().getDescriptionId(), ingredient.translationKey());
            }
        }
    }

    @Test void waterBottleDetectionIgnoresRealPotions() {
        assertTrue(BrewEngine.isWaterBottle(PotionContents.createItemStack(Items.POTION, Potions.WATER)));
        assertFalse(BrewEngine.isWaterBottle(PotionContents.createItemStack(Items.POTION, Potions.SWIFTNESS)));
        assertFalse(BrewEngine.isWaterBottle(PotionContents.createItemStack(Items.POTION, Potions.AWKWARD)));
        assertFalse(BrewEngine.isWaterBottle(new ItemStack(Items.GLASS_BOTTLE)));
        assertFalse(BrewEngine.isWaterBottle(ItemStack.EMPTY));
    }

    private static BrewCatalog.Recipe recipe(String id) {
        return BrewCatalog.RECIPES.stream().filter(r -> r.id().equals(id)).findFirst()
                .orElseThrow(() -> new AssertionError("missing recipe " + id));
    }

    private static BrewCatalog.Form form(String id) {
        return BrewCatalog.FORMS.stream().filter(f -> f.id().equals(id)).findFirst()
                .orElseThrow(() -> new AssertionError("missing form " + id));
    }
}
