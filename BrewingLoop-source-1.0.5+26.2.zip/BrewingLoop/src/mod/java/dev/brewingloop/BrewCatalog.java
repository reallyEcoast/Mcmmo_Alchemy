package dev.brewingloop;

import java.util.List;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/**
 * The potion recipes, strength variants and forms ported from the original
 * script. Ingredients are referenced through {@link Items} constants so a typo
 * is a compile error rather than a silent runtime miss.
 */
public final class BrewCatalog {
    private BrewCatalog() {
    }

    /** A brewing ingredient paired with its localisation key. */
    public record Ingredient(Item item, String translationKey) {
        public String id() {
            return translationKey;
        }
    }

    /** One brewable potion effect. */
    public record Recipe(String id, String nameKey, List<Ingredient> ingredients, List<String> variants) {
    }

    /** Duration / amplification modifier. */
    public record Variant(String id, String nameKey, Ingredient ingredient) {
    }

    /** Drink / splash / lingering conversion. */
    public record Form(String id, String nameKey, List<Ingredient> ingredients) {
    }

    public static final Ingredient NETHER_WART = new Ingredient(Items.NETHER_WART, "item.minecraft.nether_wart");
    public static final Ingredient SUGAR = new Ingredient(Items.SUGAR, "item.minecraft.sugar");
    public static final Ingredient RABBIT_FOOT = new Ingredient(Items.RABBIT_FOOT, "item.minecraft.rabbit_foot");
    public static final Ingredient GLISTERING_MELON = new Ingredient(Items.GLISTERING_MELON_SLICE, "item.minecraft.glistering_melon_slice");
    public static final Ingredient SPIDER_EYE = new Ingredient(Items.SPIDER_EYE, "item.minecraft.spider_eye");
    public static final Ingredient GOLDEN_CARROT = new Ingredient(Items.GOLDEN_CARROT, "item.minecraft.golden_carrot");
    public static final Ingredient PUFFERFISH = new Ingredient(Items.PUFFERFISH, "item.minecraft.pufferfish");
    public static final Ingredient MAGMA_CREAM = new Ingredient(Items.MAGMA_CREAM, "item.minecraft.magma_cream");
    public static final Ingredient GHAST_TEAR = new Ingredient(Items.GHAST_TEAR, "item.minecraft.ghast_tear");
    public static final Ingredient BLAZE_POWDER = new Ingredient(Items.BLAZE_POWDER, "item.minecraft.blaze_powder");
    public static final Ingredient FERMENTED_SPIDER_EYE = new Ingredient(Items.FERMENTED_SPIDER_EYE, "item.minecraft.fermented_spider_eye");
    public static final Ingredient PHANTOM_MEMBRANE = new Ingredient(Items.PHANTOM_MEMBRANE, "item.minecraft.phantom_membrane");
    // The original script listed turtle_scute here, but vanilla brews Turtle
    // Master from the Turtle Shell (the turtle_helmet item); a scute is rejected.
    public static final Ingredient TURTLE_SHELL = new Ingredient(Items.TURTLE_HELMET, "item.minecraft.turtle_helmet");
    public static final Ingredient BREEZE_ROD = new Ingredient(Items.BREEZE_ROD, "item.minecraft.breeze_rod");
    public static final Ingredient COBWEB = new Ingredient(Items.COBWEB, "block.minecraft.cobweb");
    public static final Ingredient SLIME_BLOCK = new Ingredient(Items.SLIME_BLOCK, "block.minecraft.slime_block");
    public static final Ingredient STONE = new Ingredient(Items.STONE, "block.minecraft.stone");
    public static final Ingredient REDSTONE = new Ingredient(Items.REDSTONE, "item.minecraft.redstone");
    public static final Ingredient GLOWSTONE_DUST = new Ingredient(Items.GLOWSTONE_DUST, "item.minecraft.glowstone_dust");
    public static final Ingredient GUNPOWDER = new Ingredient(Items.GUNPOWDER, "item.minecraft.gunpowder");
    public static final Ingredient DRAGON_BREATH = new Ingredient(Items.DRAGON_BREATH, "item.minecraft.dragon_breath");

    private static final List<String> ALL_THREE = List.of("normal", "long", "strong");
    private static final List<String> NO_STRONG = List.of("normal", "long");
    private static final List<String> NO_LONG = List.of("normal", "strong");
    private static final List<String> ONLY_NORMAL = List.of("normal");

    public static final List<Recipe> RECIPES = List.of(
            new Recipe("swiftness", "brewingloop.potion.swiftness", List.of(NETHER_WART, SUGAR), ALL_THREE),
            new Recipe("leaping", "brewingloop.potion.leaping", List.of(NETHER_WART, RABBIT_FOOT), ALL_THREE),
            new Recipe("healing", "brewingloop.potion.healing", List.of(NETHER_WART, GLISTERING_MELON), NO_LONG),
            new Recipe("poison", "brewingloop.potion.poison", List.of(NETHER_WART, SPIDER_EYE), ALL_THREE),
            new Recipe("night_vision", "brewingloop.potion.night_vision", List.of(NETHER_WART, GOLDEN_CARROT), NO_STRONG),
            new Recipe("strength", "brewingloop.potion.strength", List.of(NETHER_WART, BLAZE_POWDER), ALL_THREE),
            new Recipe("water_breathing", "brewingloop.potion.water_breathing", List.of(NETHER_WART, PUFFERFISH), NO_STRONG),
            new Recipe("fire_resistance", "brewingloop.potion.fire_resistance", List.of(NETHER_WART, MAGMA_CREAM), NO_STRONG),
            new Recipe("regeneration", "brewingloop.potion.regeneration", List.of(NETHER_WART, GHAST_TEAR), ALL_THREE),
            new Recipe("invisibility", "brewingloop.potion.invisibility",
                    List.of(NETHER_WART, GOLDEN_CARROT, FERMENTED_SPIDER_EYE), NO_STRONG),
            new Recipe("slowness", "brewingloop.potion.slowness",
                    List.of(NETHER_WART, SUGAR, FERMENTED_SPIDER_EYE), ALL_THREE),
            new Recipe("harming", "brewingloop.potion.harming",
                    List.of(NETHER_WART, GLISTERING_MELON, FERMENTED_SPIDER_EYE), NO_LONG),
            new Recipe("weakness", "brewingloop.potion.weakness", List.of(FERMENTED_SPIDER_EYE), NO_STRONG),
            new Recipe("slow_falling", "brewingloop.potion.slow_falling", List.of(NETHER_WART, PHANTOM_MEMBRANE), NO_STRONG),
            new Recipe("turtle_master", "brewingloop.potion.turtle_master", List.of(NETHER_WART, TURTLE_SHELL), ALL_THREE),
            new Recipe("wind_charged", "brewingloop.potion.wind_charged", List.of(NETHER_WART, BREEZE_ROD), ONLY_NORMAL),
            new Recipe("weaving", "brewingloop.potion.weaving", List.of(NETHER_WART, COBWEB), ONLY_NORMAL),
            new Recipe("oozing", "brewingloop.potion.oozing", List.of(NETHER_WART, SLIME_BLOCK), ONLY_NORMAL),
            new Recipe("infested", "brewingloop.potion.infested", List.of(NETHER_WART, STONE), ONLY_NORMAL));

    public static final List<Variant> VARIANTS = List.of(
            new Variant("normal", "brewingloop.variant.normal", null),
            new Variant("long", "brewingloop.variant.long", REDSTONE),
            new Variant("strong", "brewingloop.variant.strong", GLOWSTONE_DUST));

    public static final List<Form> FORMS = List.of(
            new Form("drink", "brewingloop.form.drink", List.of()),
            new Form("splash", "brewingloop.form.splash", List.of(GUNPOWDER)),
            new Form("lingering", "brewingloop.form.lingering", List.of(GUNPOWDER, DRAGON_BREATH)));

    public static Variant variant(String id) {
        for (Variant variant : VARIANTS) {
            if (variant.id().equals(id)) {
                return variant;
            }
        }
        return VARIANTS.getFirst();
    }

    public static List<Variant> variantsFor(Recipe recipe) {
        return VARIANTS.stream().filter(variant -> recipe.variants().contains(variant.id())).toList();
    }

    /** The ordered ingredients actually loaded into the stand for a selection. */
    public static List<Ingredient> plan(Recipe recipe, Variant variant, Form form) {
        List<Ingredient> plan = new java.util.ArrayList<>(recipe.ingredients());
        if (variant.ingredient() != null) {
            plan.add(variant.ingredient());
        }
        plan.addAll(form.ingredients());
        return List.copyOf(plan);
    }
}
