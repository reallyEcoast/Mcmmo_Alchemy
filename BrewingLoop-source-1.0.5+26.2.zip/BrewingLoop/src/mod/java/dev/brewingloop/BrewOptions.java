package dev.brewingloop;

/**
 * Everything the original script hard-coded as a top-of-file constant is a
 * runtime option here, so the user never has to edit source to change
 * behaviour. Defaults match the script's shipped values.
 */
public final class BrewOptions {

    /** What to do with a finished potion. Replaces the script's Drop / Throw pair. */
    public enum Output {
        /** Shift-click the result back into the inventory. */
        KEEP("brewingloop.option.output.keep"),
        /** Drop the result on the ground (script default: Drop = true). */
        DROP("brewingloop.option.output.drop"),
        /** Move to the hotbar and throw. Only valid for splash / lingering. */
        THROW("brewingloop.option.output.throw");

        private final String nameKey;

        Output(String nameKey) {
            this.nameKey = nameKey;
        }

        public String nameKey() {
            return nameKey;
        }
    }

    /** Where the water for the bottles comes from. */
    public enum WaterSource {
        /** Fill glass bottles by right-clicking water below the player. */
        AUTO_FILL("brewingloop.option.water.auto"),
        /** Use water bottles already carried in the inventory. */
        USE_EXISTING("brewingloop.option.water.existing");

        private final String nameKey;

        WaterSource(String nameKey) {
            this.nameKey = nameKey;
        }

        public String nameKey() {
            return nameKey;
        }
    }

    public static final int[] DELAY_CHOICES = {2, 3, 5, 8, 12};
    public static final double[] RADIUS_CHOICES = {3.0, 4.0, 6.0, 8.0};

    private Output output = Output.DROP;
    private WaterSource waterSource = WaterSource.AUTO_FILL;
    private boolean loop = true;
    private boolean highlightStands = true;
    private int actionDelay = 5;
    private double searchRadius = 4.0;
    private int loopDelay = 5;

    public Output output() {
        return output;
    }

    public void setOutput(Output output) {
        this.output = output;
    }

    public WaterSource waterSource() {
        return waterSource;
    }

    public void setWaterSource(WaterSource waterSource) {
        this.waterSource = waterSource;
    }

    public boolean loop() {
        return loop;
    }

    public void setLoop(boolean loop) {
        this.loop = loop;
    }

    public boolean highlightStands() {
        return highlightStands;
    }

    public void setHighlightStands(boolean highlightStands) {
        this.highlightStands = highlightStands;
    }

    public int actionDelay() {
        return actionDelay;
    }

    public void setActionDelay(int actionDelay) {
        this.actionDelay = Math.max(1, actionDelay);
    }

    public double searchRadius() {
        return searchRadius;
    }

    public void setSearchRadius(double searchRadius) {
        this.searchRadius = Math.max(1.0, Math.min(8.0, searchRadius));
    }

    public int loopDelay() {
        return loopDelay;
    }

    public void setLoopDelay(int loopDelay) {
        this.loopDelay = Math.max(0, loopDelay);
    }

    /**
     * THROW only makes sense for splash and lingering potions; a drinkable potion
     * would just be consumed or wasted. Callers resolve the option through this so
     * an invalid combination degrades to KEEP instead of misbehaving.
     */
    public Output resolvedOutput(String formId) {
        if (output == Output.THROW && !BrewRules.canThrow(formId)) {
            return Output.KEEP;
        }
        return output;
    }

    public BrewOptions copy() {
        BrewOptions copy = new BrewOptions();
        copy.output = output;
        copy.waterSource = waterSource;
        copy.loop = loop;
        copy.highlightStands = highlightStands;
        copy.actionDelay = actionDelay;
        copy.searchRadius = searchRadius;
        copy.loopDelay = loopDelay;
        return copy;
    }
}
