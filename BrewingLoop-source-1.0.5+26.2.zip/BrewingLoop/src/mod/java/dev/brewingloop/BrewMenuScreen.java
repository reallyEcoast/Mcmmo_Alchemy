package dev.brewingloop;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Three-step selection flow (effect, strength, form) followed by an options
 * page where every behaviour the original script hard-coded can be toggled.
 */
public class BrewMenuScreen extends Screen {
    private static final int BUTTON_HEIGHT = 20;
    private static final int GAP = 4;
    private static final int PAGE_SIZE = 12;

    private enum Step {
        RECIPE,
        VARIANT,
        FORM,
        OPTIONS
    }

    private final Consumer<BrewSelection> onConfirm;
    private final BrewOptions options;
    private final Screen parent;

    private Step step = Step.RECIPE;
    private int page;
    private BrewCatalog.Recipe recipe;
    private BrewCatalog.Variant variant;
    private BrewCatalog.Form form;

    public BrewMenuScreen(Screen parent, BrewOptions options, Consumer<BrewSelection> onConfirm) {
        super(Component.translatable("brewingloop.menu.title"));
        this.parent = parent;
        this.options = options;
        this.onConfirm = onConfirm;
    }

    @Override
    protected void init() {
        switch (step) {
            case RECIPE -> buildRecipePage();
            case VARIANT -> buildVariantPage();
            case FORM -> buildFormPage();
            case OPTIONS -> buildOptionsPage();
        }
        addFooter();
    }

    private int listTop() {
        return 44;
    }

    private void buildRecipePage() {
        List<BrewCatalog.Recipe> all = BrewCatalog.RECIPES;
        int from = page * PAGE_SIZE;
        int to = Math.min(all.size(), from + PAGE_SIZE);
        List<Button> buttons = new ArrayList<>();
        for (int i = from; i < to; i++) {
            BrewCatalog.Recipe entry = all.get(i);
            buttons.add(Button.builder(Component.translatable(entry.nameKey()), b -> {
                recipe = entry;
                variant = null;
                form = null;
                step = Step.VARIANT;
                page = 0;
                rebuildWidgets();
            }).build());
        }
        layoutGrid(buttons, 2);

        int pages = (all.size() + PAGE_SIZE - 1) / PAGE_SIZE;
        if (pages > 1) {
            addPager(pages);
        }
    }

    private void buildVariantPage() {
        List<Button> buttons = new ArrayList<>();
        for (BrewCatalog.Variant entry : BrewCatalog.variantsFor(recipe)) {
            buttons.add(Button.builder(Component.translatable(entry.nameKey()), b -> {
                variant = entry;
                step = Step.FORM;
                rebuildWidgets();
            }).build());
        }
        layoutGrid(buttons, 1);
    }

    private void buildFormPage() {
        List<Button> buttons = new ArrayList<>();
        for (BrewCatalog.Form entry : BrewCatalog.FORMS) {
            buttons.add(Button.builder(Component.translatable(entry.nameKey()), b -> {
                form = entry;
                step = Step.OPTIONS;
                rebuildWidgets();
            }).build());
        }
        layoutGrid(buttons, 1);
    }

    private void buildOptionsPage() {
        List<Button> buttons = new ArrayList<>();

        buttons.add(Button.builder(outputLabel(), b -> {
            BrewOptions.Output[] values = BrewOptions.Output.values();
            options.setOutput(values[(options.output().ordinal() + 1) % values.length]);
            rebuildWidgets();
        }).build());

        buttons.add(Button.builder(waterLabel(), b -> {
            BrewOptions.WaterSource[] values = BrewOptions.WaterSource.values();
            options.setWaterSource(values[(options.waterSource().ordinal() + 1) % values.length]);
            rebuildWidgets();
        }).build());

        buttons.add(Button.builder(toggleLabel("brewingloop.option.loop", options.loop()), b -> {
            options.setLoop(!options.loop());
            rebuildWidgets();
        }).build());

        buttons.add(Button.builder(toggleLabel("brewingloop.option.highlight", options.highlightStands()), b -> {
            options.setHighlightStands(!options.highlightStands());
            rebuildWidgets();
        }).build());

        buttons.add(Button.builder(valueLabel("brewingloop.option.delay", options.actionDelay() + " tick"), b -> {
            options.setActionDelay(nextInt(BrewOptions.DELAY_CHOICES, options.actionDelay()));
            rebuildWidgets();
        }).build());

        buttons.add(Button.builder(valueLabel("brewingloop.option.radius",
                String.format("%.0f", options.searchRadius())), b -> {
            options.setSearchRadius(nextDouble(BrewOptions.RADIUS_CHOICES, options.searchRadius()));
            rebuildWidgets();
        }).build());

        layoutGrid(buttons, 2);

        int y = listTop() + ((buttons.size() + 1) / 2) * (BUTTON_HEIGHT + GAP) + 8;
        addRenderableWidget(Button.builder(Component.translatable("brewingloop.menu.start"), b -> {
            if (onConfirm != null) {
                onConfirm.accept(BrewSelection.of(recipe, variant, form, options));
            }
            onClose();
        }).bounds(width / 2 - 100, y, 200, BUTTON_HEIGHT).build());
    }

    private Component outputLabel() {
        Component value = Component.translatable(options.output().nameKey());
        if (options.output() == BrewOptions.Output.THROW && form != null && !BrewRules.canThrow(form.id())) {
            // Honest about the downgrade instead of silently ignoring the choice.
            value = Component.translatable("brewingloop.option.output.throw_unavailable");
        }
        return Component.translatable("brewingloop.option.output", value);
    }

    private Component waterLabel() {
        return Component.translatable("brewingloop.option.water",
                Component.translatable(options.waterSource().nameKey()));
    }

    private Component toggleLabel(String key, boolean value) {
        return Component.translatable(key, Component.translatable(value
                ? "brewingloop.toggle.on"
                : "brewingloop.toggle.off"));
    }

    private Component valueLabel(String key, String value) {
        return Component.translatable(key, value);
    }

    private static int nextInt(int[] choices, int current) {
        for (int i = 0; i < choices.length; i++) {
            if (choices[i] == current) {
                return choices[(i + 1) % choices.length];
            }
        }
        return choices[0];
    }

    private static double nextDouble(double[] choices, double current) {
        for (int i = 0; i < choices.length; i++) {
            if (Math.abs(choices[i] - current) < 0.001) {
                return choices[(i + 1) % choices.length];
            }
        }
        return choices[0];
    }

    private void layoutGrid(List<Button> buttons, int columns) {
        int usable = Math.min(width - 40, 320);
        int buttonWidth = (usable - GAP * (columns - 1)) / columns;
        for (int i = 0; i < buttons.size(); i++) {
            int column = i % columns;
            int row = i / columns;
            int x = (width - usable) / 2 + column * (buttonWidth + GAP);
            int y = listTop() + row * (BUTTON_HEIGHT + GAP);
            Button button = buttons.get(i);
            button.setX(x);
            button.setY(y);
            button.setWidth(buttonWidth);
            addRenderableWidget(button);
        }
    }

    private void addPager(int pages) {
        int y = height - 52;
        addRenderableWidget(Button.builder(Component.literal("<"), b -> {
            page = (page - 1 + pages) % pages;
            rebuildWidgets();
        }).bounds(width / 2 - 104, y, 48, BUTTON_HEIGHT).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            page = (page + 1) % pages;
            rebuildWidgets();
        }).bounds(width / 2 + 56, y, 48, BUTTON_HEIGHT).build());
    }

    private void addFooter() {
        int y = height - 28;
        if (step == Step.RECIPE) {
            addRenderableWidget(Button.builder(Component.translatable("brewingloop.menu.cancel"), b -> onClose())
                    .bounds(width / 2 - 100, y, 200, BUTTON_HEIGHT).build());
            return;
        }
        addRenderableWidget(Button.builder(Component.translatable("brewingloop.menu.back"), b -> {
            step = switch (step) {
                case VARIANT -> Step.RECIPE;
                case FORM -> Step.VARIANT;
                case OPTIONS -> Step.FORM;
                case RECIPE -> Step.RECIPE;
            };
            rebuildWidgets();
        }).bounds(width / 2 - 100, y, 96, BUTTON_HEIGHT).build());
        addRenderableWidget(Button.builder(Component.translatable("brewingloop.menu.cancel"), b -> onClose())
                .bounds(width / 2 + 4, y, 96, BUTTON_HEIGHT).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(extractor, mouseX, mouseY, partialTick);
        extractor.centeredText(font, stepTitle(), width / 2, 16, 0xFFFFFF);
        Component subtitle = stepSubtitle();
        if (subtitle != null) {
            extractor.centeredText(font, subtitle, width / 2, 29, 0xA0A0A0);
        }
    }

    private Component stepTitle() {
        return switch (step) {
            case RECIPE -> Component.translatable("brewingloop.menu.step.recipe");
            case VARIANT -> Component.translatable("brewingloop.menu.step.variant");
            case FORM -> Component.translatable("brewingloop.menu.step.form");
            case OPTIONS -> Component.translatable("brewingloop.menu.step.options");
        };
    }

    private Component stepSubtitle() {
        if (step == Step.RECIPE || recipe == null) {
            return null;
        }
        if (step == Step.OPTIONS) {
            // Show the exact ingredient order that will be loaded.
            List<BrewCatalog.Ingredient> plan = BrewCatalog.plan(recipe, variant, form);
            var text = Component.translatable(recipe.nameKey()).append(Component.literal(": "))
                    .append(Component.translatable("brewingloop.menu.water_bottle"));
            for (BrewCatalog.Ingredient ingredient : plan) {
                text.append(Component.literal(" > "))
                        .append(Component.translatable(ingredient.translationKey()));
            }
            return text;
        }
        return Component.translatable(recipe.nameKey());
    }

    @Override
    public void onClose() {
        minecraft.gui.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
