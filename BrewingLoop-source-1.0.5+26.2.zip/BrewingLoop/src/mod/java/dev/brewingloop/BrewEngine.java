package dev.brewingloop;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.BrewingStandMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Main-thread tick state machine driving the brewing loop.
 *
 * <p>Every behaviour the original script hard-coded is read from
 * {@link BrewOptions} instead. Anything unexpected pauses rather than guessing,
 * so a wrong assumption never turns into lost items.
 */
public final class BrewEngine {
    /** Brewing stand slot indices inside {@link BrewingStandMenu}. */
    static final int[] POTION_SLOTS = {0, 1, 2};
    static final int INGREDIENT_SLOT = 3;
    static final int FUEL_SLOT = 4;
    /** Player inventory slots start after the five stand slots. */
    static final int PLAYER_SLOT_START = 5;

    private static final int OPEN_TIMEOUT_TICKS = 100;
    /** How long to wait for a swap click to take effect before pausing. */
    private static final int SWAP_TIMEOUT_TICKS = 60;

    enum State {
        IDLE,
        FIND,
        OPENING,
        PREPARE,
        FILL_BOTTLES,
        LOAD_INGREDIENT,
        WAIT_BREW,
        COLLECT,
        THROW_OUTPUT,
        LOOP_WAIT,
        PAUSED;

        /**
         * Whether this state can only run with the stand's own menu open, which
         * decides how resuming works: these have to re-open the stand they were
         * working on, the rest can simply continue where they stopped.
         */
        boolean needsOpenStand() {
            return switch (this) {
                case PREPARE, LOAD_INGREDIENT, WAIT_BREW, COLLECT -> true;
                default -> false;
            };
        }
    }

    private final Minecraft mc;

    private State state = State.IDLE;
    private State afterOpen = State.PREPARE;
    private BrewSelection selection;

    private final List<BlockPos> stands = new ArrayList<>();
    private int standIndex;
    private int ingredientIndex;
    private int round;
    private int collected;

    private int delayTicks;
    private int openWaitTicks;
    private int loopWaitTicks;
    private int bottlesToFill;
    private int swapWaitTicks;
    private int pausedTicks;
    private int lastShownSecond = -1;
    private Integer trackedContainerId;

    /** State to return to when the player resumes; never {@code PAUSED}. */
    private State resumeState = State.FIND;

    private String status = "";
    private String pauseReason = "";

    public BrewEngine(Minecraft mc) {
        this.mc = mc;
    }

    public boolean isActive() {
        return state != State.IDLE;
    }

    public boolean isPaused() {
        return state == State.PAUSED;
    }

    /** Short line for the HUD overlay. */
    public String status() {
        if (state == State.PAUSED) {
            return Component.translatable("brewingloop.status.paused", pauseReason).getString();
        }
        return status;
    }

    /** Stands the renderer should highlight; empty when highlighting is off. */
    public List<BlockPos> highlightedStands() {
        if (state == State.IDLE || selection == null || !selection.options().highlightStands()) {
            return List.of();
        }
        return List.copyOf(stands);
    }

    public void start(BrewSelection selection) {
        this.selection = selection;
        stands.clear();
        standIndex = 0;
        ingredientIndex = 0;
        round = 0;
        collected = 0;
        delayTicks = 0;
        trackedContainerId = null;
        lastShownSecond = -1;
        resumeState = State.FIND;
        state = State.FIND;
        chat(Component.translatable("brewingloop.message.started", recipeSummary()), ChatFormatting.GREEN);
    }

    public void togglePause() {
        if (state == State.IDLE) {
            return;
        }
        if (state == State.PAUSED) {
            resume();
            return;
        }
        pause(Component.translatable("brewingloop.pause.manual"));
    }

    /**
     * Picks the work back up at the step that was interrupted.
     *
     * <p>Earlier versions resumed by jumping to {@code FIND}, which restarted the
     * whole round: {@code tickFind} bumps the round counter and resets the stand
     * and ingredient cursors, so a stand that was already half-brewed got a fresh
     * set of water bottles and a second copy of every ingredient. Pausing is
     * meant to be a break, not a rollback.
     *
     * <p>States that drive the stand's GUI cannot just continue, because pausing
     * closes that GUI — they re-open the exact stand they were on, keeping the
     * cursors untouched, and the step they were in re-reads the stand's real
     * contents anyway, so nothing is double-applied.
     */
    private void resume() {
        State target = resumeState;
        delayTicks = 0;
        lastShownSecond = -1;
        chat(Component.translatable("brewingloop.message.resumed"), ChatFormatting.GREEN);

        if (target.needsOpenStand()) {
            if (stands.isEmpty() || standIndex >= stands.size()) {
                // Nothing left to point at; a rescan is the honest fallback.
                trackedContainerId = null;
                state = State.FIND;
                return;
            }
            openStand(stands.get(standIndex), target);
            return;
        }
        trackedContainerId = null;
        state = target;
    }

    public void stop(Component reason) {
        if (state == State.IDLE) {
            return;
        }
        state = State.IDLE;
        trackedContainerId = null;
        stands.clear();
        status = "";
        closeStandScreen();
        chat(Component.translatable("brewingloop.message.stopped", reason, collected), ChatFormatting.GREEN);
    }

    private void pause(Component reason) {
        pauseReason = reason.getString();
        // Remember the interrupted step so resuming continues instead of restarting.
        // OPENING is not resumable in itself; whatever it was opening for is.
        resumeState = state == State.OPENING ? afterOpen : state;
        state = State.PAUSED;
        pausedTicks = 0;
        trackedContainerId = null;
        // Close the stand so the player can freely reorganise their inventory.
        closeStandScreen();
        Component line = Component.translatable("brewingloop.message.pausedHint", reason);
        chat(line, ChatFormatting.YELLOW);
        overlay(line, ChatFormatting.YELLOW);
    }

    public void tick() {
        if (state == State.IDLE) {
            return;
        }
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) {
            // World unloaded: drop everything without pretending work continues.
            state = State.IDLE;
            stands.clear();
            trackedContainerId = null;
            status = "";
            return;
        }
        if (!player.isAlive() || player.isSpectator()) {
            stop(Component.translatable("brewingloop.stop.playerState"));
            return;
        }
        if (state == State.PAUSED) {
            // The overlay message fades; keep the reason on screen while stopped.
            if (++pausedTicks % 40 == 0) {
                overlay(Component.literal(status()), ChatFormatting.YELLOW);
            }
            return;
        }
        if (delayTicks > 0) {
            delayTicks--;
            return;
        }

        switch (state) {
            case FIND -> tickFind();
            case OPENING -> tickOpening();
            case PREPARE -> tickPrepare();
            case FILL_BOTTLES -> tickFillBottles();
            case LOAD_INGREDIENT -> tickLoadIngredient();
            case WAIT_BREW -> tickWaitBrew();
            case COLLECT -> tickCollect();
            case THROW_OUTPUT -> tickThrowOutput();
            case LOOP_WAIT -> tickLoopWait();
            default -> {
            }
        }
    }

    // ---------------------------------------------------------------- finding

    private void tickFind() {
        LocalPlayer player = mc.player;
        BlockPos origin = player.blockPosition();
        double radius = selection.options().searchRadius();
        int range = (int) Math.ceil(radius);

        stands.clear();
        for (int dx = -range; dx <= range; dx++) {
            for (int dy = -range; dy <= range; dy++) {
                for (int dz = -range; dz <= range; dz++) {
                    BlockPos pos = origin.offset(dx, dy, dz);
                    if (!mc.level.getBlockState(pos).is(Blocks.BREWING_STAND)) {
                        continue;
                    }
                    if (player.getEyePosition().distanceTo(Vec3.atCenterOf(pos)) > radius) {
                        continue;
                    }
                    if (!hasClearView(pos)) {
                        continue;
                    }
                    stands.add(pos.immutable());
                }
            }
        }

        if (stands.isEmpty()) {
            pause(Component.translatable("brewingloop.pause.noStand", String.format("%.0f", radius)));
            return;
        }
        // Nearest first, so progress messages follow a predictable order.
        Vec3 eye = player.getEyePosition();
        stands.sort((a, b) -> Double.compare(
                eye.distanceToSqr(Vec3.atCenterOf(a)), eye.distanceToSqr(Vec3.atCenterOf(b))));

        round++;
        standIndex = 0;
        ingredientIndex = 0;
        setStatus(Component.translatable("brewingloop.status.found", round, stands.size()));
        openStand(stands.getFirst(), State.PREPARE);
    }

    /** Refuses to interact through walls, the way a player physically could not. */
    private boolean hasClearView(BlockPos pos) {
        LocalPlayer player = mc.player;
        HitResult hit = mc.level.clip(new ClipContext(player.getEyePosition(), Vec3.atCenterOf(pos),
                ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
        if (hit.getType() != HitResult.Type.BLOCK) {
            return true;
        }
        return ((BlockHitResult) hit).getBlockPos().equals(pos);
    }

    // --------------------------------------------------------------- opening

    private void openStand(BlockPos pos, State next) {
        if (!mc.level.getBlockState(pos).is(Blocks.BREWING_STAND)) {
            pause(Component.translatable("brewingloop.pause.standGone"));
            return;
        }
        if (!hasClearView(pos)) {
            pause(Component.translatable("brewingloop.pause.obstructed"));
            return;
        }
        afterOpen = next;
        trackedContainerId = null;
        openWaitTicks = 0;
        state = State.OPENING;
        lastShownSecond = -1;

        LocalPlayer player = mc.player;
        player.lookAt(EntityAnchorArgument.Anchor.EYES, Vec3.atCenterOf(pos));
        mc.gameMode.useItemOn(player, InteractionHand.MAIN_HAND,
                new BlockHitResult(Vec3.atCenterOf(pos), Direction.UP, pos, false));
        delayTicks = selection.options().actionDelay();
    }

    private void tickOpening() {
        BrewingStandMenu menu = screenMenu();
        if (menu != null) {
            trackedContainerId = menu.containerId;
            state = afterOpen;
            return;
        }
        if (++openWaitTicks > OPEN_TIMEOUT_TICKS) {
            // Never silently skip to another stand: pause so the player can look.
            pause(Component.translatable("brewingloop.pause.openTimeout"));
        }
    }

    private BrewingStandMenu screenMenu() {
        if (mc.gui.screen() instanceof AbstractContainerScreen<?> screen
                && screen.getMenu() instanceof BrewingStandMenu menu) {
            return menu;
        }
        return null;
    }

    /** The menu we opened, or null if the player closed or swapped screens. */
    private BrewingStandMenu ownedMenu() {
        BrewingStandMenu menu = screenMenu();
        if (menu == null || trackedContainerId == null || menu.containerId != trackedContainerId) {
            return null;
        }
        return menu;
    }

    // --------------------------------------------------------------- prepare

    private void tickPrepare() {
        BrewingStandMenu menu = ownedMenu();
        if (menu == null) {
            pause(Component.translatable("brewingloop.pause.menuClosed"));
            return;
        }

        // 1. Fuel first, so the stand can actually brew.
        if (BrewRules.needsFuel(menu.getFuel()) && !menu.getSlot(FUEL_SLOT).getItem().is(Items.BLAZE_POWDER)) {
            int source = findPlayerSlot(menu, Items.BLAZE_POWDER);
            if (source < 0) {
                pause(Component.translatable("brewingloop.pause.noFuel"));
                return;
            }
            setStatus(Component.translatable("brewingloop.status.fuel", round));
            moveSingle(menu, source, FUEL_SLOT);
            return;
        }

        // 2. Three water bottles in the potion slots.
        int loaded = countLoadedWaterBottles(menu);
        if (loaded < BrewRules.POTION_SLOTS) {
            int target = findFreePotionSlot(menu);
            if (target < 0) {
                // Every potion slot is taken, yet fewer than three hold water.
                // Something else is sitting in the stand - very often leftover
                // glass bottles, which the potion slots happily accept. Blindly
                // clicking here moves nothing at all, so say what is wrong
                // instead of retrying forever.
                pause(Component.translatable("brewingloop.pause.potionSlotBlocked",
                        describeBlockedPotionSlots(menu)));
                return;
            }

            int carried = findWaterBottleSlot(menu);
            if (carried >= 0) {
                setStatus(Component.translatable("brewingloop.status.loadWater", round));
                // Aim at a known-free potion slot rather than quick-moving and
                // hoping: quick-move silently does nothing when slots 0-2 are
                // full, which is exactly how this used to stall.
                moveSingle(menu, carried, target);
                return;
            }
            if (isWaterBottle(mc.player.getOffhandItem())) {
                // The brewing menu has no off-hand slot, so the bottle has to
                // come into the main inventory before it can be clicked.
                setStatus(Component.translatable("brewingloop.status.loadWater", round));
                swapOffhandIntoHotbar(menu);
                return;
            }

            int wanted = BrewRules.missingBottles(loaded);
            if (selection.options().waterSource() == BrewOptions.WaterSource.AUTO_FILL) {
                beginFillBottles(wanted);
                return;
            }
            // Carrying glass bottles with auto-fill switched off is a settings
            // problem, not a missing-item problem; say which it is.
            int glass = countInventoryItem(Items.GLASS_BOTTLE);
            pause(glass > 0
                    ? Component.translatable("brewingloop.pause.noWaterBottleHasGlass", wanted, glass)
                    : Component.translatable("brewingloop.pause.noWaterBottle", wanted));
            return;
        }

        // 3. Verify the whole round's materials before committing any of them.
        Component missing = missingStock(menu);
        if (missing != null) {
            pause(missing);
            return;
        }

        if (standIndex + 1 < stands.size()) {
            standIndex++;
            setStatus(Component.translatable("brewingloop.status.prepare", standIndex + 1, stands.size()));
            openStand(stands.get(standIndex), State.PREPARE);
            return;
        }

        // Every stand holds water and fuel; start the ingredient stages.
        standIndex = 0;
        ingredientIndex = 0;
        openStand(stands.getFirst(), State.LOAD_INGREDIENT);
    }

    // --------------------------------------------------------- bottle filling

    /**
     * Auto-filling needs the stand GUI closed and the player holding a glass
     * bottle, so it runs as its own state and re-opens the stand afterwards.
     *
     * <p>Counting happens against the player's own inventory rather than the
     * stand menu's slot list: the stand menu only exposes the 27 storage slots
     * plus the 9 hotbar slots, and reading it while the screen is mid-close
     * reports nothing at all. Either way bottles sitting in the off-hand or in
     * the hotbar were previously invisible, which made the mod claim there were
     * no glass bottles while the player could plainly see them.
     */
    private void beginFillBottles(int wanted) {
        int glass = countInventoryItem(Items.GLASS_BOTTLE);
        if (glass < wanted) {
            pause(Component.translatable("brewingloop.pause.noGlassBottle", wanted, glass));
            return;
        }
        if (!BrewRules.canFillBottles(glass, countFreeInventorySlots(), wanted)) {
            pause(Component.translatable("brewingloop.pause.noSpace", wanted));
            return;
        }

        bottlesToFill = wanted;
        trackedContainerId = null;
        closeStandScreen();
        state = State.FILL_BOTTLES;
        setStatus(Component.translatable("brewingloop.status.fillWater", wanted, round));
        delayTicks = selection.options().actionDelay();
    }

    /**
     * Selects a hotbar slot that already holds glass bottles. Changing the
     * selected slot is a plain client action, so it works with no container
     * open; the previous version needed an open menu and a SWAP click, which is
     * exactly why it failed once the stand screen had been closed.
     */
    private boolean selectGlassBottle() {
        Inventory inventory = mc.player.getInventory();
        if (inventory.getSelectedItem().is(Items.GLASS_BOTTLE)) {
            return true;
        }
        var items = inventory.getNonEquipmentItems();
        for (int slot = 0; slot < Inventory.SELECTION_SIZE; slot++) {
            if (items.get(slot).is(Items.GLASS_BOTTLE)) {
                inventory.setSelectedSlot(slot);
                return true;
            }
        }
        if (mc.player.getOffhandItem().is(Items.GLASS_BOTTLE)) {
            // Swap the off-hand stack into the held slot. Button 40 is the
            // off-hand, the one index outside the hotbar that SWAP accepts.
            swapIntoSelectedSlot(Inventory.SLOT_OFFHAND);
            return false;
        }
        // Bottles are in storage only: move a stack down into the held slot.
        int source = findInventorySlot(inventory, Items.GLASS_BOTTLE);
        if (source < 0) {
            return false;
        }
        swapIntoSelectedSlot(source);
        return false;
    }

    /**
     * Issues a SWAP that pulls {@code source} into the currently selected hotbar
     * slot, addressed through the player's own inventory menu.
     *
     * <p>The source index is a player-inventory index and has to be converted:
     * {@code InventoryMenu} lists a result slot, the crafting grid and the armour
     * slots first, so the 27 storage slots sit at menu 9-35 and the hotbar at
     * 36-44. Sending a raw inventory index here would click a crafting or armour
     * slot instead.
     */
    private void swapIntoSelectedSlot(int source) {
        Inventory inventory = mc.player.getInventory();
        int menuSlot = BrewRules.inventoryMenuSlotFor(source);
        if (menuSlot < 0) {
            pause(Component.translatable("brewingloop.pause.swapFailed"));
            return;
        }
        mc.gameMode.handleContainerInput(mc.player.inventoryMenu.containerId, menuSlot,
                inventory.getSelectedSlot(), ContainerInput.SWAP, mc.player);
        delayTicks = selection.options().actionDelay();
    }

    private void tickFillBottles() {
        if (bottlesToFill <= 0) {
            openStand(stands.get(standIndex), State.PREPARE);
            return;
        }
        LocalPlayer player = mc.player;
        if (!selectGlassBottle()) {
            if (countInventoryItem(Items.GLASS_BOTTLE) > 0) {
                // A swap was just issued; let it land before filling. Bound the
                // wait so a rejected click pauses with a reason instead of
                // spinning here silently for ever.
                if (++swapWaitTicks <= SWAP_TIMEOUT_TICKS) {
                    return;
                }
                pause(Component.translatable("brewingloop.pause.swapFailed"));
                return;
            }
            pause(Component.translatable("brewingloop.pause.bottleNotHeld"));
            return;
        }
        swapWaitTicks = 0;
        if (!isWaterUnderPlayer()) {
            pause(Component.translatable("brewingloop.pause.noWaterSource"));
            return;
        }

        // Aim straight down at the water before using the bottle.
        player.lookAt(EntityAnchorArgument.Anchor.EYES, player.getEyePosition().add(0.0, -1.0, 0.0));
        mc.gameMode.useItem(player, InteractionHand.MAIN_HAND);
        bottlesToFill--;
        delayTicks = selection.options().actionDelay();
    }

    /** Filling requires water at the player's feet or just below them. */
    private boolean isWaterUnderPlayer() {
        BlockPos feet = mc.player.blockPosition();
        return mc.level.getFluidState(feet).is(FluidTags.WATER)
                || mc.level.getFluidState(feet.below()).is(FluidTags.WATER);
    }

    // ----------------------------------------------------------- ingredients

    private void tickLoadIngredient() {
        BrewingStandMenu menu = ownedMenu();
        if (menu == null) {
            pause(Component.translatable("brewingloop.pause.menuClosed"));
            return;
        }
        List<BrewCatalog.Ingredient> plan = selection.plan();
        BrewCatalog.Ingredient ingredient = plan.get(ingredientIndex);

        // A stage already in progress must finish before the next item goes in.
        if (menu.getBrewingTicks() > 0) {
            showBrewingProgress(menu);
            delayTicks = 2;
            return;
        }
        if (!menu.getSlot(INGREDIENT_SLOT).getItem().isEmpty()) {
            // Slot occupied but no progress yet: let the server catch up.
            delayTicks = 2;
            return;
        }

        int source = findPlayerSlot(menu, ingredient.item());
        if (source < 0) {
            pause(Component.translatable("brewingloop.pause.missingIngredient",
                    Component.translatable(ingredient.translationKey())));
            return;
        }

        setStatus(Component.translatable("brewingloop.status.ingredient",
                ingredientIndex + 1, plan.size(),
                Component.translatable(ingredient.translationKey()),
                standIndex + 1, stands.size()));
        moveSingle(menu, source, INGREDIENT_SLOT);
        advanceAfterIngredient();
    }

    /** Walks the batch order: every stand per stage, then the next stage. */
    private void advanceAfterIngredient() {
        if (standIndex + 1 < stands.size()) {
            standIndex++;
            openStand(stands.get(standIndex), State.LOAD_INGREDIENT);
            return;
        }
        standIndex = 0;
        if (ingredientIndex + 1 < selection.plan().size()) {
            ingredientIndex++;
            openStand(stands.getFirst(), State.LOAD_INGREDIENT);
            return;
        }
        openStand(stands.getFirst(), State.WAIT_BREW);
    }

    private void tickWaitBrew() {
        BrewingStandMenu menu = ownedMenu();
        if (menu == null) {
            pause(Component.translatable("brewingloop.pause.menuClosed"));
            return;
        }
        if (menu.getBrewingTicks() > 0) {
            showBrewingProgress(menu);
            delayTicks = 2;
            return;
        }
        state = State.COLLECT;
    }

    private void showBrewingProgress(BrewingStandMenu menu) {
        int seconds = BrewRules.remainingSeconds(menu.getBrewingTicks());
        if (seconds == lastShownSecond) {
            return;
        }
        lastShownSecond = seconds;
        setStatus(Component.translatable("brewingloop.status.brewing",
                seconds, standIndex + 1, stands.size()));
    }

    // --------------------------------------------------------------- collect

    private void tickCollect() {
        BrewingStandMenu menu = ownedMenu();
        if (menu == null) {
            pause(Component.translatable("brewingloop.pause.menuClosed"));
            return;
        }

        for (int slot : POTION_SLOTS) {
            ItemStack stack = menu.getSlot(slot).getItem();
            if (stack.isEmpty() || isWaterBottle(stack)) {
                // A leftover water bottle is not a finished potion.
                continue;
            }
            int count = stack.getCount();
            if (selection.resolvedOutput() == BrewOptions.Output.DROP) {
                mc.gameMode.handleContainerInput(menu.containerId, slot, 1, ContainerInput.THROW, mc.player);
            } else {
                if (!hasRoomFor(menu, stack)) {
                    pause(Component.translatable("brewingloop.pause.inventoryFull"));
                    return;
                }
                quickMove(menu, slot);
            }
            collected += count;
            setStatus(Component.translatable("brewingloop.status.collect", standIndex + 1, stands.size()));
            delayTicks = selection.options().actionDelay();
            return;
        }

        // This stand is drained. Output handling happens here, per stand, rather
        // than once at the end of the round: holding the output of every stand at
        // the same time is what filled the inventory up and stalled the next
        // round. DROP goes through the same state so that potions which ended up
        // in the inventory anyway - a previous KEEP run, a half-finished round,
        // or a throw that was interrupted - still get cleared out instead of
        // sitting there for ever.
        if (selection.resolvedOutput() != BrewOptions.Output.KEEP) {
            trackedContainerId = null;
            closeStandScreen();
            state = State.THROW_OUTPUT;
            delayTicks = selection.options().actionDelay();
            return;
        }
        continueAfterCollect();
    }

    /** Moves to the next stand to collect, or ends the round after the last one. */
    private void continueAfterCollect() {
        if (standIndex + 1 < stands.size()) {
            standIndex++;
            openStand(stands.get(standIndex), State.WAIT_BREW);
            return;
        }
        trackedContainerId = null;
        closeStandScreen();
        finishRound();
    }

    /**
     * Clears the finished potions out of the inventory. With THROW they are
     * thrown by using them; with DROP they are dropped on the ground. Only the
     * player's own inventory is ever used as a source. This runs after each
     * stand, so the player never carries more than one stand's output.
     *
     * <p>DROP also lands here, which is what finally empties potions that were
     * already in the inventory rather than only the ones still in the stand.
     */
    private void tickThrowOutput() {
        LocalPlayer player = mc.player;
        Inventory inventory = player.getInventory();
        boolean drop = selection.resolvedOutput() == BrewOptions.Output.DROP;
        Item wanted = outputItem();

        if (drop) {
            // Dropping needs no held slot: a THROW click works on any slot of
            // the player's own inventory menu.
            int slot = findOutputSlot(inventory, wanted);
            if (slot < 0) {
                if (isOutput(player.getOffhandItem(), wanted)) {
                    dropFromInventory(Inventory.SLOT_OFFHAND);
                    return;
                }
                swapWaitTicks = 0;
                continueAfterCollect();
                return;
            }
            setStatus(Component.translatable("brewingloop.status.dropping", round));
            dropFromInventory(slot);
            return;
        }

        ItemStack held = inventory.getSelectedItem();
        if (isThrowable(held)) {
            setStatus(Component.translatable("brewingloop.status.throwing", round));
            mc.gameMode.useItem(player, InteractionHand.MAIN_HAND);
            delayTicks = selection.options().actionDelay();
            return;
        }

        int slot = findOutputSlot(inventory, Items.SPLASH_POTION);
        if (slot < 0) {
            slot = findOutputSlot(inventory, Items.LINGERING_POTION);
        }
        if (slot < 0) {
            if (isThrowable(player.getOffhandItem())) {
                // Nothing in the main inventory, but the off-hand holds output.
                swapIntoSelectedSlot(Inventory.SLOT_OFFHAND);
                return;
            }
            swapWaitTicks = 0;
            continueAfterCollect();
            return;
        }
        if (slot < Inventory.SELECTION_SIZE) {
            // Already on the hotbar: selecting it needs no container at all,
            // which matters because the stand screen is closed here.
            inventory.setSelectedSlot(slot);
            return;
        }
        if (++swapWaitTicks > SWAP_TIMEOUT_TICKS) {
            // The swap is not landing. Say so rather than looping for ever.
            pause(Component.translatable("brewingloop.pause.swapFailed"));
            return;
        }
        swapIntoSelectedSlot(slot);
    }

    /** Drops a whole stack from the player's own inventory onto the ground. */
    private void dropFromInventory(int inventorySlot) {
        int menuSlot = BrewRules.inventoryMenuSlotFor(inventorySlot);
        if (menuSlot < 0) {
            swapWaitTicks = 0;
            continueAfterCollect();
            return;
        }
        // Button 1 drops the entire stack; button 0 would drop a single item.
        mc.gameMode.handleContainerInput(mc.player.inventoryMenu.containerId, menuSlot, 1,
                ContainerInput.THROW, mc.player);
        delayTicks = selection.options().actionDelay();
    }

    /** The item the configured form actually produces. */
    private Item outputItem() {
        return switch (selection.form().id()) {
            case "splash" -> Items.SPLASH_POTION;
            case "lingering" -> Items.LINGERING_POTION;
            default -> Items.POTION;
        };
    }

    /**
     * Whether a stack is finished output rather than raw material.
     *
     * <p>Water bottles are {@code minecraft:potion} as well, so for the drinkable
     * form the item id alone cannot tell output from input. Dropping on the item
     * id would throw away the water bottles the next round needs.
     */
    private static boolean isOutput(ItemStack stack, Item wanted) {
        return stack.is(wanted) && !isWaterBottle(stack);
    }

    /** First inventory slot holding finished output of the given item. */
    private static int findOutputSlot(Inventory inventory, Item wanted) {
        var items = inventory.getNonEquipmentItems();
        for (int i = 0; i < items.size(); i++) {
            if (isOutput(items.get(i), wanted)) {
                return i;
            }
        }
        return -1;
    }

    /** Only splash and lingering potions can be thrown. */
    private static boolean isThrowable(ItemStack stack) {
        return stack.is(Items.SPLASH_POTION) || stack.is(Items.LINGERING_POTION);
    }

    private void finishRound() {
        chat(Component.translatable("brewingloop.message.roundDone", round, collected), ChatFormatting.GREEN);
        if (!selection.options().loop()) {
            stop(Component.translatable("brewingloop.stop.singleRound"));
            return;
        }
        loopWaitTicks = selection.options().loopDelay();
        state = State.LOOP_WAIT;
    }

    private void tickLoopWait() {
        if (loopWaitTicks > 0) {
            loopWaitTicks--;
            return;
        }
        state = State.FIND;
    }

    // ----------------------------------------------------------- menu helpers

    /**
     * Moves exactly one item: pick the stack up, right-click to place a single
     * item, then put the remainder back where it came from.
     */
    private void moveSingle(BrewingStandMenu menu, int from, int to) {
        int id = menu.containerId;
        mc.gameMode.handleContainerInput(id, from, 0, ContainerInput.PICKUP, mc.player);
        mc.gameMode.handleContainerInput(id, to, 1, ContainerInput.PICKUP, mc.player);
        mc.gameMode.handleContainerInput(id, from, 0, ContainerInput.PICKUP, mc.player);
        delayTicks = selection.options().actionDelay();
    }

    private void quickMove(BrewingStandMenu menu, int slot) {
        mc.gameMode.handleContainerInput(menu.containerId, slot, 0, ContainerInput.QUICK_MOVE, mc.player);
        delayTicks = selection.options().actionDelay();
    }

    private int findPlayerSlot(BrewingStandMenu menu, Item item) {
        for (int i = PLAYER_SLOT_START; i < menu.slots.size(); i++) {
            if (menu.getSlot(i).getItem().is(item)) {
                return i;
            }
        }
        return -1;
    }

    private int countPlayerItem(BrewingStandMenu menu, Item item) {
        int total = 0;
        for (int i = PLAYER_SLOT_START; i < menu.slots.size(); i++) {
            ItemStack stack = menu.getSlot(i).getItem();
            if (stack.is(item)) {
                total += stack.getCount();
            }
        }
        return total;
    }

    /**
     * Counts an item across the player's whole inventory, independent of any
     * open container. Unlike the menu-slot scan this sees the hotbar and the
     * off-hand, and it keeps working after the stand screen has been closed.
     */
    private int countInventoryItem(Item item) {
        int total = 0;
        var items = mc.player.getInventory().getNonEquipmentItems();
        for (int i = 0; i < items.size(); i++) {
            ItemStack stack = items.get(i);
            if (stack.is(item)) {
                total += stack.getCount();
            }
        }
        ItemStack offhand = mc.player.getOffhandItem();
        if (offhand.is(item)) {
            total += offhand.getCount();
        }
        return total;
    }

    private static int findInventorySlot(Inventory inventory, Item item) {
        var items = inventory.getNonEquipmentItems();
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).is(item)) {
                return i;
            }
        }
        return -1;
    }

    /** A water bottle is a potion whose contents are the water potion. */
    static boolean isWaterBottle(ItemStack stack) {
        if (!stack.is(Items.POTION)) {
            return false;
        }
        PotionContents contents = stack.get(DataComponents.POTION_CONTENTS);
        return contents != null && contents.is(Potions.WATER);
    }

    private int countLoadedWaterBottles(BrewingStandMenu menu) {
        int count = 0;
        for (int slot : POTION_SLOTS) {
            if (isWaterBottle(menu.getSlot(slot).getItem())) {
                count++;
            }
        }
        return count;
    }

    /**
     * Finds a water bottle to load, returning a <em>menu</em> slot index.
     *
     * <p>Scanning goes through the player's own inventory rather than the menu's
     * slot list. The two are not interchangeable: a brewing stand menu only
     * mirrors the 36 storage slots, and its indices are ordered main-rows-first
     * while the inventory puts the hotbar first. Reading the inventory directly
     * and converting afterwards keeps one source of truth, and it is why the
     * caller can also handle the off-hand, which no container menu exposes.
     */
    private int findWaterBottleSlot(BrewingStandMenu menu) {
        var items = mc.player.getInventory().getNonEquipmentItems();
        int limit = Math.min(items.size(), BrewRules.STORAGE_SIZE);
        for (int slot = 0; slot < limit; slot++) {
            if (!isWaterBottle(items.get(slot))) {
                continue;
            }
            int menuSlot = BrewRules.menuSlotForInventorySlot(slot);
            // Trust the menu over the arithmetic: if the layout ever changes,
            // a mismatch must not turn into a click on the wrong slot.
            if (menuSlot >= 0 && menuSlot < menu.slots.size()
                    && isWaterBottle(menu.getSlot(menuSlot).getItem())) {
                return menuSlot;
            }
        }
        return -1;
    }

    /** A potion slot we can actually place a water bottle into. */
    private int findFreePotionSlot(BrewingStandMenu menu) {
        for (int slot : POTION_SLOTS) {
            if (menu.getSlot(slot).getItem().isEmpty()) {
                return slot;
            }
        }
        return -1;
    }

    /** Names whatever is occupying the potion slots, for the pause message. */
    private Component describeBlockedPotionSlots(BrewingStandMenu menu) {
        for (int slot : POTION_SLOTS) {
            ItemStack stack = menu.getSlot(slot).getItem();
            if (!stack.isEmpty() && !isWaterBottle(stack)) {
                return Component.translatable(stack.getItem().getDescriptionId());
            }
        }
        return Component.translatable(Items.POTION.getDescriptionId());
    }

    /**
     * Swaps the off-hand stack into the hotbar slot the menu can reach. The
     * off-hand is button 40 of a SWAP click, the one index outside the hotbar
     * range that {@code doClick} accepts.
     */
    private void swapOffhandIntoHotbar(BrewingStandMenu menu) {
        Inventory inventory = mc.player.getInventory();
        int hotbar = inventory.getSelectedSlot();
        if (!inventory.getSelectedItem().isEmpty()) {
            int free = findEmptyHotbarSlot(inventory);
            if (free >= 0) {
                hotbar = free;
            }
        }
        int menuSlot = BrewRules.menuSlotForInventorySlot(hotbar);
        if (menuSlot < 0 || menuSlot >= menu.slots.size()) {
            pause(Component.translatable("brewingloop.pause.noSpace", 1));
            return;
        }
        mc.gameMode.handleContainerInput(menu.containerId, menuSlot, Inventory.SLOT_OFFHAND,
                ContainerInput.SWAP, mc.player);
        delayTicks = selection.options().actionDelay();
    }

    private static int findEmptyHotbarSlot(Inventory inventory) {
        var items = inventory.getNonEquipmentItems();
        for (int slot = 0; slot < Inventory.SELECTION_SIZE; slot++) {
            if (items.get(slot).isEmpty()) {
                return slot;
            }
        }
        return -1;
    }

    private int countFreeInventorySlots() {
        var items = mc.player.getInventory().getNonEquipmentItems();
        int free = 0;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).isEmpty()) {
                free++;
            }
        }
        return free;
    }

    private boolean hasRoomFor(BrewingStandMenu menu, ItemStack stack) {
        for (int i = PLAYER_SLOT_START; i < menu.slots.size(); i++) {
            ItemStack existing = menu.getSlot(i).getItem();
            if (existing.isEmpty()) {
                return true;
            }
            if (ItemStack.isSameItemSameComponents(existing, stack)
                    && existing.getCount() + stack.getCount() <= existing.getMaxStackSize()) {
                return true;
            }
        }
        return false;
    }

    /** Checks the whole round's material needs up front, like the script did. */
    private Component missingStock(BrewingStandMenu menu) {
        Map<Item, Integer> needed = new LinkedHashMap<>();
        for (BrewCatalog.Ingredient ingredient : selection.plan()) {
            needed.merge(ingredient.item(), stands.size(), Integer::sum);
        }
        for (Map.Entry<Item, Integer> entry : needed.entrySet()) {
            int have = countPlayerItem(menu, entry.getKey());
            if (have < entry.getValue()) {
                return Component.translatable("brewingloop.pause.lowStock",
                        Component.translatable(entry.getKey().getDescriptionId()),
                        entry.getValue(), have);
            }
        }
        return null;
    }

    /**
     * Closes the stand screen <em>and</em> the container behind it.
     *
     * <p>{@code setScreen(null)} only runs the screen's {@code removed()} hook.
     * It never sends the close packet, so the server keeps the brewing stand
     * open and the player's {@code containerMenu} stays pointed at the stand
     * rather than back at {@code inventoryMenu}. Every later click aimed at the
     * player's own inventory menu then carried the wrong container id and the
     * server rejected it, which is why glass bottles in storage were never
     * swapped into the hand and finished potions were never thrown.
     * {@code onClose()} sends the packet and resets the menu.
     */
    private void closeStandScreen() {
        if (mc.gui.screen() instanceof AbstractContainerScreen<?> screen) {
            screen.onClose();
        }
        // Belt and braces: if anything else had already dropped the screen, make
        // sure we are not still holding a stale container id.
        if (mc.player.containerMenu != mc.player.inventoryMenu) {
            mc.player.closeContainer();
        }
    }

    // ---------------------------------------------------------------- output

    private Component recipeSummary() {
        return Component.translatable(selection.recipe().nameKey())
                .append(Component.literal(" / "))
                .append(Component.translatable(selection.variant().nameKey()))
                .append(Component.literal(" / "))
                .append(Component.translatable(selection.form().nameKey()));
    }

    private void setStatus(Component text) {
        status = text.getString();
        overlay(text, ChatFormatting.AQUA);
    }

    private void overlay(Component text, ChatFormatting color) {
        if (mc.player != null) {
            mc.gui.hud.setOverlayMessage(text.copy().withStyle(color), false);
        }
    }

    private void chat(Component text, ChatFormatting color) {
        if (mc.player != null) {
            mc.player.sendSystemMessage(Component.translatable("brewingloop.prefix")
                    .append(text).withStyle(color));
        }
    }
}
