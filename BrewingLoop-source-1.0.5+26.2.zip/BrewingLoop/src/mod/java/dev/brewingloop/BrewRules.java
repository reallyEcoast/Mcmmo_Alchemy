package dev.brewingloop;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Pure brewing rules with no Minecraft dependency so they can be unit tested
 * without a client. Everything here is deterministic.
 */
public final class BrewRules {
    private BrewRules() {
    }

    /** Potion slots in a brewing stand menu. */
    public static final int POTION_SLOTS = 3;

    /** Hotbar size, and the index where the main inventory starts. */
    public static final int HOTBAR_SIZE = 9;
    /** Main inventory plus hotbar, excluding equipment and the off-hand. */
    public static final int STORAGE_SIZE = 36;
    /** A brewing stand menu lists its own five slots before the player's. */
    public static final int MENU_MAIN_START = 5;
    /** The hotbar follows the 27 main inventory slots. */
    public static final int MENU_HOTBAR_START = 32;

    /**
     * Translates a slot index in the player's own inventory into the slot index
     * the brewing stand menu uses for it.
     *
     * <p>The two numbering schemes disagree in an easy-to-miss way: the player's
     * inventory puts the hotbar first (0-8) and the main rows after it (9-35),
     * while every container menu lists the main rows first and the hotbar last.
     * Mixing them up clicks a slot three rows away from the intended one.
     *
     * @return the menu slot, or {@code -1} for anything the menu cannot reach,
     *         which includes the off-hand and the armour slots
     */
    public static int menuSlotForInventorySlot(int inventorySlot) {
        if (inventorySlot < 0 || inventorySlot >= STORAGE_SIZE) {
            return -1;
        }
        if (inventorySlot < HOTBAR_SIZE) {
            return MENU_HOTBAR_START + inventorySlot;
        }
        return MENU_MAIN_START + (inventorySlot - HOTBAR_SIZE);
    }

    /** Slot indices inside the player's own inventory menu. */
    public static final int INVENTORY_MENU_STORAGE_START = 9;
    public static final int INVENTORY_MENU_HOTBAR_START = 36;
    public static final int INVENTORY_MENU_OFFHAND = 45;
    /** The off-hand's index in {@code Inventory}, unrelated to the menu index. */
    public static final int INVENTORY_OFFHAND = 40;

    /**
     * Translates a player-inventory index into the slot index of the player's
     * <em>own</em> inventory menu, for use as the target of a click.
     *
     * <p>This is a different mapping from {@link #menuSlotForInventorySlot}:
     * {@code InventoryMenu} puts a crafting result, the 2x2 grid and the four
     * armour slots first, so storage lands at 9-35, the hotbar at 36-44 and the
     * off-hand at 45. Sending a raw inventory index would hit a crafting or
     * armour slot instead of the intended item.
     *
     * @return the menu slot, or {@code -1} if the index addresses nothing
     *         clickable such as an armour slot
     */
    public static int inventoryMenuSlotFor(int inventorySlot) {
        if (inventorySlot == INVENTORY_OFFHAND) {
            return INVENTORY_MENU_OFFHAND;
        }
        if (inventorySlot < 0 || inventorySlot >= STORAGE_SIZE) {
            return -1;
        }
        if (inventorySlot < HOTBAR_SIZE) {
            return INVENTORY_MENU_HOTBAR_START + inventorySlot;
        }
        return INVENTORY_MENU_STORAGE_START + (inventorySlot - HOTBAR_SIZE);
    }

    /**
     * Builds the ordered ingredient plan: base ingredients, then the duration /
     * amplification modifier, then the form conversion ingredients. Order matters
     * because the brewing stand applies one ingredient per stage.
     */
    public static List<String> ingredientPlan(List<String> base, String modifier, List<String> formIngredients) {
        List<String> plan = new ArrayList<>(base);
        if (modifier != null && !modifier.isBlank()) {
            plan.add(modifier);
        }
        plan.addAll(formIngredients);
        return List.copyOf(plan);
    }

    /**
     * Total material count needed to run one round across every stand. Each stage
     * consumes exactly one item per stand, so duplicated ingredients accumulate.
     */
    public static Map<String, Integer> totalStock(List<String> plan, int standCount) {
        Map<String, Integer> needed = new LinkedHashMap<>();
        if (standCount <= 0) {
            return Map.of();
        }
        for (String ingredient : plan) {
            needed.merge(ingredient, standCount, Integer::sum);
        }
        return Map.copyOf(needed);
    }

    /** How many water bottles are still missing from the three potion slots. */
    public static int missingBottles(int loadedWaterBottles) {
        return Math.max(0, POTION_SLOTS - Math.max(0, loadedWaterBottles));
    }

    /**
     * Fuel is consumed one blaze powder per 20 brewing operations. A stage needs
     * fuel present; this reports whether a refill click is required right now.
     */
    public static boolean needsFuel(int remainingFuelUses) {
        return remainingFuelUses <= 0;
    }

    /**
     * Whether the inventory can accept the bottles we are about to fill. Filling
     * water bottles converts a glass bottle in hand into a water bottle, so empty
     * slots are only needed when the glass bottles sit in a single stack.
     */
    public static boolean canFillBottles(int glassBottleCount, int freeSlots, int wanted) {
        if (wanted <= 0) {
            return true;
        }
        if (glassBottleCount < wanted) {
            return false;
        }
        return freeSlots >= wanted;
    }

    /** Remaining brewing seconds, rounded up, for the status display. */
    public static int remainingSeconds(int remainingTicks) {
        if (remainingTicks <= 0) {
            return 0;
        }
        return (remainingTicks + 19) / 20;
    }

    /**
     * The item the finished potion ends up as, given the selected form. Used to
     * decide which stacks are throwable.
     */
    public static String outputItem(String formId) {
        return switch (formId) {
            case "splash" -> "minecraft:splash_potion";
            case "lingering" -> "minecraft:lingering_potion";
            default -> "minecraft:potion";
        };
    }

    /** Only splash and lingering potions can be thrown. */
    public static boolean canThrow(String formId) {
        return "splash".equals(formId) || "lingering".equals(formId);
    }
}
