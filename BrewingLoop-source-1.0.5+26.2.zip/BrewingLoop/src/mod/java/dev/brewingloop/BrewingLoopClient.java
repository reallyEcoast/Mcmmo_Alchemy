package dev.brewingloop;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.Window;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.BrewingStandScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

/** Client-only entry point; all input and engine work stays on the Minecraft client thread. */
public final class BrewingLoopClient implements ClientModInitializer {
    /** Shared across runs so the user's choices survive closing the menu. */
    private final BrewOptions options = new BrewOptions();

    private BrewEngine engine;
    private Hotkey openMenu;
    private Hotkey pause;
    private Hotkey stop;

    @Override
    public void onInitializeClient() {
        Minecraft minecraft = Minecraft.getInstance();
        engine = new BrewEngine(minecraft);
        StandHighlight highlight = new StandHighlight(engine);

        KeyMapping.Category category = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath("brewingloop", "controls"));
        openMenu = register("menu", GLFW.GLFW_KEY_B, category);
        pause = register("pause", GLFW.GLFW_KEY_V, category);
        stop = register("stop", GLFW.GLFW_KEY_X, category);

        LevelRenderEvents.AFTER_TRANSLUCENT_TERRAIN.register(highlight::render);

        // Vanilla does not update normal key mappings while a container screen is open.
        // Match the actual rebound keys here and queue actions for the next START tick.
        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (!(screen instanceof BrewingStandScreen)) {
                return;
            }
            ScreenKeyboardEvents.allowKeyPress(screen).register((current, event) -> {
                if (!engine.isActive()) {
                    return true;
                }
                boolean handled = stop.keyPressed(event);
                handled |= pause.keyPressed(event);
                return !handled;
            });
            ScreenKeyboardEvents.allowKeyRelease(screen).register((current, event) -> {
                stop.keyReleased(event);
                pause.keyReleased(event);
                return true;
            });
            ScreenMouseEvents.allowMouseClick(screen).register((current, event) -> {
                if (!engine.isActive()) {
                    return true;
                }
                boolean handled = stop.mousePressed(event);
                handled |= pause.mousePressed(event);
                return !handled;
            });
            ScreenMouseEvents.allowMouseRelease(screen).register((current, event) -> {
                stop.mouseReleased(event);
                pause.mouseReleased(event);
                return true;
            });
        });

        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            // Poll every tick, even in unrelated screens, so a held key cannot become a
            // new press merely by closing a menu. No hard-coded key state is consulted.
            boolean stopPressed = stop.poll(client);
            boolean pausePressed = pause.poll(client);
            boolean menuPressed = openMenu.poll(client);
            boolean inWorld = client.level != null && client.player != null;
            Screen screen = client.gui.screen();
            // The engine drives the stand GUI itself, so V / X must work there too.
            boolean controlContext = screen == null || screen instanceof BrewingStandScreen;
            if (inWorld && client.isWindowActive()) {
                // Stop has priority if keys conflict or are pressed on the same tick.
                if (stopPressed && controlContext) {
                    if (engine.isActive()) {
                        engine.stop(Component.translatable("brewingloop.stop.manual"));
                    }
                } else if (pausePressed && controlContext) {
                    if (engine.isActive()) {
                        engine.togglePause();
                    }
                } else if (menuPressed && screen == null) {
                    if (engine.isActive()) {
                        engine.stop(Component.translatable("brewingloop.stop.reconfigure"));
                    }
                    client.gui.setScreen(new BrewMenuScreen(null, options, engine::start));
                }
            }
            // START runs before player movement. Also tick while unloaded: the engine
            // owns disconnect/world-change cleanup.
            engine.tick();
        });
    }

    private static Hotkey register(String name, int defaultKey, KeyMapping.Category category) {
        return new Hotkey(KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.brewingloop." + name, InputConstants.Type.KEYSYM, defaultKey, category)));
    }

    /** Edge-triggered input; supports normal, mouse and unknown/scancode key bindings. */
    private static final class Hotkey {
        private final KeyMapping mapping;
        private boolean held;
        private boolean queued;
        private boolean scancodeHeld;
        private int scancodeKeysym = GLFW.GLFW_KEY_UNKNOWN;
        private InputConstants.Key lastBound;

        private Hotkey(KeyMapping mapping) {
            this.mapping = mapping;
            lastBound = KeyMappingHelper.getBoundKeyOf(mapping);
        }

        private boolean keyPressed(KeyEvent event) {
            if (!mapping.matches(event)) {
                return false;
            }
            scancodeHeld = true;
            scancodeKeysym = event.key();
            press();
            return true;
        }

        private void keyReleased(KeyEvent event) {
            if (mapping.matches(event)) {
                held = false;
                scancodeHeld = false;
                scancodeKeysym = GLFW.GLFW_KEY_UNKNOWN;
            }
        }

        private boolean mousePressed(MouseButtonEvent event) {
            if (!mapping.matchesMouse(event)) {
                return false;
            }
            press();
            return true;
        }

        private void mouseReleased(MouseButtonEvent event) {
            if (mapping.matchesMouse(event)) {
                held = false;
            }
        }

        private void press() {
            if (!held) {
                queued = true;
            }
            held = true;
        }

        private boolean poll(Minecraft client) {
            InputConstants.Key bound = KeyMappingHelper.getBoundKeyOf(mapping);
            boolean rebound = !bound.equals(lastBound);
            if (rebound) {
                queued = false;
                scancodeHeld = false;
                scancodeKeysym = GLFW.GLFW_KEY_UNKNOWN;
                lastBound = bound;
            }
            boolean clicked = false;
            while (mapping.consumeClick()) {
                clicked = true;
            }
            if (!client.isWindowActive() || mapping.isUnbound()) {
                held = false;
                queued = false;
                scancodeHeld = false;
                return false;
            }
            boolean down = physicalDown(client.getWindow(), bound);
            // consumeClick also catches an ordinary-world tap shorter than one tick.
            boolean pressed = queued || (!held && (down || clicked));
            queued = false;
            held = down;
            // Rebinding in Controls must not execute that binding on the same tick.
            return !rebound && pressed;
        }

        private boolean physicalDown(Window window, InputConstants.Key bound) {
            return switch (bound.getType()) {
                case KEYSYM -> bound.getValue() >= 0 && InputConstants.isKeyDown(window, bound.getValue());
                case MOUSE -> bound.getValue() >= 0 && bound.getValue() <= GLFW.GLFW_MOUSE_BUTTON_LAST
                    && GLFW.glfwGetMouseButton(window.handle(), bound.getValue()) == GLFW.GLFW_PRESS;
                // GLFW cannot directly poll an unknown physical scan code. Screen key
                // events track it; ordinary gameplay still uses the mapping's state.
                case SCANCODE -> scancodeHeld && scancodeKeysym != GLFW.GLFW_KEY_UNKNOWN
                    ? InputConstants.isKeyDown(window, scancodeKeysym)
                    : scancodeHeld || mapping.isDown();
            };
        }
    }
}
