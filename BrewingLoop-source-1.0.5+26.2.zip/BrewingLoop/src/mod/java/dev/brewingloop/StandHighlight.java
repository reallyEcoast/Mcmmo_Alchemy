package dev.brewingloop;

import com.mojang.blaze3d.vertex.PoseStack;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Draws a wireframe box around every stand the engine is currently working on,
 * replacing the script's {@code showBoxes} / {@code color} constants. Purely
 * visual: it reads engine state and never changes it.
 */
public final class StandHighlight {
    /** Same footprint the script drew: the stand's own column plus one block up. */
    private static final VoxelShape SHAPE = Shapes.create(0.375, 0.0, 0.375, 0.625, 1.0, 0.625);
    /** 0x66CC00 from the script, made fully opaque. */
    private static final int COLOR = 0xFF66CC00;
    private static final float LINE_WIDTH = 2.0f;

    private final BrewEngine engine;

    public StandHighlight(BrewEngine engine) {
        this.engine = engine;
    }

    public void render(LevelRenderContext context) {
        List<BlockPos> stands = engine.highlightedStands();
        if (stands.isEmpty()) {
            return;
        }
        Vec3 camera = context.levelState().cameraRenderState.pos;
        PoseStack poseStack = context.poseStack();
        for (BlockPos pos : stands) {
            poseStack.pushPose();
            // Block coordinates are world-absolute; the render pass is camera-relative.
            poseStack.translate(pos.getX() - camera.x, pos.getY() - camera.y, pos.getZ() - camera.z);
            context.submitNodeCollector()
                    .submitShapeOutline(poseStack, SHAPE, RenderTypes.lines(), COLOR, LINE_WIDTH, false);
            poseStack.popPose();
        }
    }
}
