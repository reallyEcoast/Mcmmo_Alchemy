package dev.brewingloop;

import java.util.List;

/** The finished configuration handed to the engine when the user confirms. */
public record BrewSelection(
        BrewCatalog.Recipe recipe,
        BrewCatalog.Variant variant,
        BrewCatalog.Form form,
        List<BrewCatalog.Ingredient> plan,
        BrewOptions options) {

    public static BrewSelection of(BrewCatalog.Recipe recipe, BrewCatalog.Variant variant,
                                   BrewCatalog.Form form, BrewOptions options) {
        return new BrewSelection(recipe, variant, form,
                BrewCatalog.plan(recipe, variant, form), options.copy());
    }

    public BrewOptions.Output resolvedOutput() {
        return options.resolvedOutput(form.id());
    }
}
