# BrewingLoop

A client-side Fabric mod for **Minecraft 26.2** that automates a brewing stand loop,
with every setting chosen from an in-game menu instead of being hard-coded.

Originally a [JsMacros](https://github.com/JsMacros/JsMacros) script. The script's
constants (`Water`, `Drop`, `Throw`, `distance`, `delay`, `Loop`, `showBoxes`) are now
options you pick before each run.

> Automation on multiplayer servers may be against the rules. Check before using it.

---

## Features

- **4-step selection menu** — potion → strength → form → options. Only strengths the
  game can actually brew are offered.
- **19 potions**, all three forms (drinkable / splash / lingering), and extended /
  upgraded variants.
- **Batch brewing** across every brewing stand in range, stage by stage.
- **Three output modes** — keep in inventory, drop on the ground, or throw. Throwing
  happens per stand so the inventory never fills up.
- **Pauses instead of guessing.** Out of an ingredient, out of blaze powder, inventory
  full, stand mined away, GUI refused to open, no water underfoot — the mod closes the
  GUI, says exactly what is wrong, and waits. Pressing resume continues the interrupted
  step; it does not restart the round.
- **Four languages** — `en_us`, `zh_tw`, `zh_hk`, `zh_cn`.
- Optional outline rendering on the stands it is driving.

## Controls

| Default key | Action |
|---|---|
| <kbd>B</kbd> | Open the brewing menu |
| <kbd>V</kbd> | Pause / resume |
| <kbd>X</kbd> | Stop |

Rebindable under Options → Controls → Key Binds → Brewing. The keys work while the
brewing stand screen is open, so there is no need to close it first.

## Options

| Option | Values | Script constant it replaces |
|---|---|---|
| Finished potion | keep / drop / throw | `Drop`, `Throw` |
| Water bottles | auto-fill from water below / use carried bottles | `Water` |
| Repeat forever | on / off | `Loop` |
| Highlight stands | on / off | `showBoxes` |
| Action delay | 2 / 3 / 5 / 8 / 12 ticks | `delay` |
| Search radius | 3 / 4 / 6 / 8 blocks | `distance` |

Defaults match the original script's constants, so changing nothing reproduces the
script's behaviour. Choices persist until the game closes.

`throw` only makes sense for splash and lingering potions; picking it for a drinkable
potion degrades to `keep` and the button says so, rather than wasting the output.

---

## Requirements

| | |
|---|---|
| Minecraft | 26.2 |
| Fabric Loader | 0.19.3+ |
| Fabric API | 0.154.0+26.2 |
| Java | 25+ |

## Install

Drop the jar from [Releases](../../releases) into `.minecraft/mods/`. Client only —
nothing to install server-side.

## Build from source

```sh
git clone https://github.com/<you>/BrewingLoop.git
cd BrewingLoop
./gradlew build          # gradlew.bat build on Windows
```

The jar lands in `build/libs/`. `./gradlew test` runs the test suite on its own.

Target versions live in [`gradle.properties`](gradle.properties) — change
`minecraft_version` / `fabric_api_version` there to build against another release.

---

## How it works

A single tick-driven state machine on the client thread. No threads, no reflection, no
mixins — it issues the same container clicks a player would, spaced by the configured
delay.

```
FIND ─→ OPENING ─→ PREPARE ─┬─→ FILL_BOTTLES ─┐
                            │                 │
                            └────── LOAD_INGREDIENT ─→ WAIT_BREW ─→ COLLECT
                                                                       │
                                            LOOP_WAIT ←─ THROW_OUTPUT ←┘
```

Any state can drop into `PAUSED`, which records the interrupted state. Resuming returns
there: GUI-driven steps re-open the stand they were working on, the rest simply continue.
Those steps re-read the stand's real contents, so nothing is applied twice.

| File | Role |
|---|---|
| `BrewEngine.java` | The state machine and all container interaction |
| `BrewCatalog.java` | Recipes, variants, forms, and ingredient order |
| `BrewRules.java` | Pure logic: ingredient plans, stock maths, timing |
| `BrewOptions.java` | User-selectable settings with clamping |
| `BrewMenuScreen.java` | The 4-step selection GUI |
| `StandHighlight.java` | Outline rendering |

### Tests

`./gradlew test` — 37 tests, no game instance needed.

- `BrewCatalogTest` replays every recipe × variant through vanilla's real
  `PotionBrewing` table, and asserts the excluded combinations really are rejected. This
  is what caught a bug inherited from the script: it brewed the Turtle Master potion from
  a **turtle scute**, but vanilla requires a **turtle shell** — the scute is refused and
  the script would have waited forever.
- `BrewRulesTest` covers ingredient order, stock maths, and timing arithmetic.
- `BrewOptionsTest` pins the defaults to the script's constants and checks clamping.
- `BrewStateTest` pins which states must re-open a stand when resuming.
- `LangCoverageTest` scrapes every translation key out of the sources and asserts all
  four locales define it, with matching format-argument positions (not just matching `%`
  counts — Chinese reorders arguments with `%2$s`).
- `DependencyMetadataTest` pins the declared dependency ranges.

---

## Known limitations

- Minecraft 26.2 only. Mojang's unobfuscated names are used directly, so other versions
  need a rebuild and possibly source changes.
- The stand must be in line of sight; the mod will not interact through blocks.
- Auto-filling water bottles needs water at or just below the player's feet.

## License

[CC0 1.0 Universal](LICENSE) — public domain. Do whatever you want with it.
